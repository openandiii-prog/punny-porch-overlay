'use client'

// WHAT MUST SURVIVE ANY REWRITE (see CLAUDE.md "Plugin Infrastructure"):
//   - the `/store/contact` POST, its `_hp` honeypot field, and the FetchError
//     429 branch. A form that does not reach this endpoint silently discards
//     every customer enquiry while telling the customer it was sent.
//   - `usePolicies()` and the contact_email / contact_phone / contact_address
//     reads: real merchant data, never placeholder text.
//   - the `<form onSubmit={handleSubmit}>` wiring.
// No response times or opening hours appear here because the store has not stated any.

import { useState } from 'react'
import { FetchError } from '@medusajs/js-sdk'
import { toast } from 'sonner'
import { getMedusaClient } from '@/lib/medusa-client'
import { usePolicies } from '@/hooks/use-policies'
import PorchPage from '@/components/porch/porch-page'
import { Sticker } from '@/components/porch/decor'
import { PageBand } from '@/components/porch/page-parts'
import { field, label, pill, wrap } from '@/components/porch/ui'

const TOPICS = ['Order inquiry', 'Product question', 'Returns & exchanges', 'Other']

export default function ContactPage() {
  const { policies, isLoading, error } = usePolicies()

  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [email, setEmail] = useState('')
  const [topic, setTopic] = useState('')
  const [message, setMessage] = useState('')
  const [honeypot, setHoneypot] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (isSubmitting) return

    setIsSubmitting(true)
    try {
      await getMedusaClient().client.fetch('/store/contact', {
        method: 'POST',
        body: {
          name: `${firstName} ${lastName}`.trim(),
          email: email.trim(),
          message: topic ? `Topic: ${topic}\n\n${message}` : message,
          _hp: honeypot,
        },
      })

      toast.success("Message sent! We'll get back to you soon.")
      setFirstName('')
      setLastName('')
      setEmail('')
      setTopic('')
      setMessage('')
    } catch (err) {
      if (err instanceof FetchError && err.status === 429) {
        toast.error('Too many messages sent. Please try again later.')
      } else {
        toast.error('Failed to send your message. Please try again.')
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const contactEmail = policies?.contact_email
  const contactPhone = policies?.contact_phone
  const contactAddress = policies?.contact_address
  const hasDetails = Boolean(contactEmail || contactPhone || contactAddress)

  return (
    <PorchPage>
      <PageBand eyebrow="Porch mail" title="Contact Us" />

      <div className={`${wrap} grid gap-12 py-14 sm:py-20 lg:grid-cols-[1.3fr_0.7fr] lg:gap-16`}>
        <form
          onSubmit={handleSubmit}
          className="relative grid gap-5 rounded-[30px] border-2 border-border bg-background p-6 shadow-[8px_9px_0_hsl(var(--accent))] sm:grid-cols-2 sm:p-9"
        >
          <div>
            <label htmlFor="contact-first-name" className={label}>First name</label>
            <input id="contact-first-name" type="text" required maxLength={100} autoComplete="given-name" value={firstName} onChange={(e) => setFirstName(e.target.value)} className={field} />
          </div>

          <div>
            <label htmlFor="contact-last-name" className={label}>Last name</label>
            <input id="contact-last-name" type="text" maxLength={99} autoComplete="family-name" value={lastName} onChange={(e) => setLastName(e.target.value)} className={field} />
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="contact-email" className={label}>Email address</label>
            <input id="contact-email" type="email" required maxLength={320} autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className={field} />
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="contact-topic" className={label}>Topic</label>
            <select id="contact-topic" value={topic} onChange={(e) => setTopic(e.target.value)} className={field}>
              <option value="">Select a topic</option>
              {TOPICS.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="contact-message" className={label}>Your message</label>
            <textarea id="contact-message" rows={5} required maxLength={4900} value={message} onChange={(e) => setMessage(e.target.value)} className={field} />
          </div>

          {/* Honeypot: hidden from humans; bots that fill it are silently dropped server-side */}
          <input type="text" name="_hp" value={honeypot} onChange={(e) => setHoneypot(e.target.value)} tabIndex={-1} autoComplete="off" aria-hidden="true" style={{ position: 'absolute', left: '-9999px' }} />

          <div className="sm:col-span-2">
            <button type="submit" disabled={isSubmitting} className={pill}>
              {isSubmitting ? 'Sending…' : 'Send Message'}
            </button>
          </div>
        </form>

        <aside className="flex flex-col items-start">
          <Sticker name="ghost-wave" float="a" className="mb-6 h-36 w-auto" />
          {/* Merchant-configured contact details. Never replace with placeholder
              text: a store with none configured shows nothing here, by design. */}
          {isLoading ? (
            <p className="font-bold text-muted-foreground">Loading contact information…</p>
          ) : error ? (
            <p className="font-bold text-muted-foreground">Unable to load contact information. Please try again later.</p>
          ) : hasDetails ? (
            <address className="space-y-2 text-lg font-bold not-italic leading-7">
              {contactEmail && <p><a href={`mailto:${contactEmail}`} className="underline underline-offset-4">{contactEmail}</a></p>}
              {contactPhone && <p>{contactPhone}</p>}
              {contactAddress && <p style={{ whiteSpace: 'pre-line' }}>{contactAddress}</p>}
            </address>
          ) : null}
        </aside>
      </div>
    </PorchPage>
  )
}

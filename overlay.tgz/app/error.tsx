'use client'

import { useEffect } from 'react'
import { AlertCircle, RefreshCw, Home } from 'lucide-react'
import Link from 'next/link'
import { pill, pillGhost } from '@/components/porch/ui'

// Keep `reset()` and the error boundary contract. This screen deliberately does not render the
// shared header and footer: if one of them is what failed, the error screen must still show.
export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error('Route error:', error)
  }, [error])

  return (
    <div className="porch grid min-h-screen place-items-center bg-background px-5 py-16 text-foreground">
      <div className="w-full max-w-lg rounded-[36px_36px_36px_12px] border-2 border-border bg-muted px-7 py-12 text-center shadow-[8px_9px_0_hsl(var(--accent))]">
        <AlertCircle aria-hidden size={40} strokeWidth={2.2} className="mx-auto text-primary" />
        <h2 className="mt-5 font-heading text-4xl leading-none">Something went wrong</h2>
        <p className="mx-auto mt-4 max-w-sm leading-7 text-muted-foreground">
          We encountered an unexpected error. Please try again or return to the homepage.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button
            onClick={reset}
            className={pill}
          >
            <RefreshCw aria-hidden size={16} strokeWidth={2.6} />
            Try Again
          </button>
          <Link
            href="/"
            className={`${pillGhost} bg-background`}
          >
            <Home aria-hidden size={16} strokeWidth={2.6} />
            Homepage
          </Link>
        </div>
      </div>
    </div>
  )
}

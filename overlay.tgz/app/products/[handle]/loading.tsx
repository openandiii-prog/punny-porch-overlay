import PorchPage from '@/components/porch/porch-page'
import { wrap } from '@/components/porch/ui'

const block = 'animate-pulse rounded-full bg-muted'

// Loading state shaped like the product page: photos on the left, the buy block on the right.
export default function ProductDetailLoading() {
  return (
    <PorchPage>
      <div aria-hidden className={`${wrap} grid gap-10 pb-20 pt-16 lg:grid-cols-[1.08fr_0.92fr] lg:gap-14`}>
        <div className="grid grid-cols-2 gap-3 sm:gap-5">
          <div className="col-span-2 aspect-[4/4.5] animate-pulse rounded-3xl bg-muted" />
          <div className="aspect-square animate-pulse rounded-2xl bg-muted" />
          <div className="aspect-square animate-pulse rounded-2xl bg-muted" />
        </div>
        <div>
          <div className={`${block} h-3 w-40`} />
          <div className="mt-5 h-16 w-4/5 animate-pulse rounded-2xl bg-muted" />
          <div className={`${block} mt-8 h-9 w-28`} />
          <div className="mt-8 flex flex-wrap gap-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className={`${block} h-11 w-14`} />
            ))}
          </div>
          <div className={`${block} mt-8 h-12 w-full`} />
        </div>
      </div>
    </PorchPage>
  )
}

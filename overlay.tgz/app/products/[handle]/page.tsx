import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import ProductActions from '@/components/product/product-actions'
import { getProductPlaceholder } from '@/lib/utils/placeholder-images'
import { type VariantExtension } from '@/components/product/product-price'
import { PluginSlot } from '@/components/PluginSlot'
import { medusaServerClient } from '@/lib/medusa-client'
import { applyContentMetadata, getSeoDescription, getSeoTitle } from '@/lib/utils/content-metadata'
import PorchPage from '@/components/porch/porch-page'

export const revalidate = 0

async function getProduct(handle: string) {
  try {
    const regionsResponse = await medusaServerClient.store.region.list()
    const regionId = regionsResponse.regions[0]?.id
    if (!regionId) throw new Error('No region found')
    const response = await medusaServerClient.store.product.list({ handle, region_id: regionId, fields: '*variants.calculated_price,+metadata' })
    const product = response.products?.[0]
    return product ? applyContentMetadata(product) : null
  } catch (error) {
    console.error('Error fetching product:', error)
    return null
  }
}

async function getVariantExtensions(productId: string): Promise<Record<string, VariantExtension>> {
  try {
    const baseUrl = process.env.NEXT_PUBLIC_MEDUSA_BACKEND_URL || 'http://localhost:9000'
    const storeId = process.env.NEXT_PUBLIC_STORE_ID
    const publishableKey = process.env.NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY
    const headers: Record<string, string> = {}
    if (storeId) headers['X-Store-Environment-ID'] = storeId
    if (publishableKey) headers['x-publishable-api-key'] = publishableKey
    const res = await fetch(`${baseUrl}/store/product-extensions/products/${productId}/variants`, { headers, next: { revalidate: 30 } })
    if (!res.ok) return {}
    const data = await res.json()
    const map: Record<string, VariantExtension> = {}
    for (const v of data.variants || []) map[v.id] = { compare_at_price: v.compare_at_price, allow_backorder: v.allow_backorder ?? false, inventory_quantity: v.inventory_quantity }
    return map
  } catch {
    return {}
  }
}

export async function generateMetadata({ params }: { params: Promise<{ handle: string }> }): Promise<Metadata> {
  const { handle } = await params
  const product = await getProduct(handle)
  if (!product) return { title: 'Product Not Found' }
  const title = getSeoTitle(product)
  const description = getSeoDescription(product) || `Shop ${title}`
  return { title, description, openGraph: { title, description, ...(product.thumbnail ? { images: [{ url: product.thumbnail }] } : {}) } }
}

export default async function ProductPage({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params
  const product = await getProduct(handle)
  if (!product) notFound()

  const variantExtensions = await getVariantExtensions(product.id)
  const images = product.images?.length ? product.images.map((img: { url: string }) => img.url) : [product.thumbnail || getProductPlaceholder(product.id)]

  return (
    <PorchPage>
      <PluginSlot name="pdpAnalytics" context={{ productId: product.id, productName: product.title, sku: product.handle, price: product.variants?.[0]?.calculated_price?.calculated_amount, currency: product.variants?.[0]?.calculated_price?.currency_code }} />

      <div className="mx-auto max-w-[1440px] px-5 pb-20 pt-6 sm:px-8 lg:px-12 lg:pt-10">
        <Link href="/products" className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.14em] text-accent transition-colors hover:text-primary">← Back to the tees</Link>

        <div className="mt-6 grid gap-10 lg:grid-cols-[1.08fr_0.92fr] lg:gap-14">
          <section className="grid grid-cols-2 gap-3 sm:gap-5" aria-label={`${product.title} photos`}>
            {images.map((src: string, index: number) => (
              <div key={src} className={index === 0 ? 'col-span-2 aspect-[4/4.5] overflow-hidden rounded-3xl bg-muted' : 'aspect-square overflow-hidden rounded-2xl bg-muted'}>
                <Image src={src} alt={`${product.title}${index ? `, view ${index + 1}` : ''}`} width={1200} height={1200} priority={index === 0} sizes="(min-width: 1024px) 48vw, 100vw" className="h-full w-full object-cover" />
              </div>
            ))}
          </section>

          <section className="lg:sticky lg:top-24 lg:h-fit">
            <p className="text-xs font-black uppercase tracking-[0.16em] text-accent">A porch-party original</p>
            <h1 className="mt-3 font-heading text-5xl leading-[0.9] tracking-[-0.045em] sm:text-6xl">{product.title}</h1>
            <PluginSlot name="pdpAfterTitle" context={{ productId: product.id, productName: product.title }} />
            <PluginSlot name="pdpBeforePrice" context={{ productId: product.id, price: product.variants?.[0]?.calculated_price?.calculated_price }} />
            <ProductActions product={product} variantExtensions={variantExtensions} />
            <PluginSlot name="pdpBelowAddToCart" context={{ productId: product.id }} />
            <PluginSlot name="pdpTrustSignals" context={{ productId: product.id }} />

            <div className="mt-8 grid gap-3 border-y-2 border-border py-6 text-sm font-bold sm:grid-cols-3 sm:text-center">
              <p><span className="block font-heading text-2xl text-primary">01</span>Made to order</p>
              <p><span className="block font-heading text-2xl text-primary">02</span>Cozy everyday fit</p>
              <p><span className="block font-heading text-2xl text-primary">03</span>Big fall feelings</p>
            </div>
          </section>
        </div>

        <section className="mt-16 grid gap-8 border-t-2 border-border pt-12 lg:grid-cols-[0.75fr_1.25fr] lg:gap-16">
          <div><p className="text-xs font-black uppercase tracking-[0.16em] text-accent">The good stuff</p><h2 className="mt-3 font-heading text-4xl leading-none tracking-[-0.04em] sm:text-5xl">Designed for the season, made for every day.</h2></div>
          {product.description && <div className="prose prose-lg max-w-none prose-headings:font-heading prose-headings:tracking-tight prose-p:text-muted-foreground prose-p:leading-7 prose-li:text-muted-foreground prose-li:marker:text-primary" dangerouslySetInnerHTML={{ __html: product.description }} />}
        </section>

        <PluginSlot name="pdpAfterDescription" context={{ productId: product.id }} />
        <PluginSlot name="pdpTab" context={{ productId: product.id }} />
      </div>

      <section className="border-t-2 border-border bg-muted px-5 py-12 sm:px-8 lg:px-12"><div className="mx-auto flex max-w-[1440px] flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="text-xs font-black uppercase tracking-[0.16em] text-accent">More porch magic</p><h2 className="mt-2 font-heading text-4xl leading-none tracking-[-0.04em] sm:text-5xl">Your fall uniform starts here.</h2></div><Link href="/products" className="w-fit rounded-full bg-primary px-6 py-3.5 text-xs font-black uppercase tracking-[0.13em] text-primary-foreground shadow-[4px_5px_0_hsl(var(--foreground))] transition-transform hover:-translate-y-0.5">Shop all tees</Link></div></section>
    </PorchPage>
  )
}

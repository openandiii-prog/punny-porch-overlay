import PorchPage from '@/components/porch/porch-page'
import { BandSkeleton, GridSkeleton } from '@/components/porch/page-parts'
import { wrap } from '@/components/porch/ui'

// Loading state shaped like the shop page itself, so nothing jumps when the tees arrive.
export default function ProductsLoading() {
  return (
    <PorchPage>
      <BandSkeleton />
      <div className={`${wrap} py-12 sm:py-16`}>
        <GridSkeleton count={8} />
      </div>
    </PorchPage>
  )
}

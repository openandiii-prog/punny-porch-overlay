'use client'

import { Suspense, useRef, useState } from 'react'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { ChevronDown } from 'lucide-react'
import ProductGrid from '@/components/product/product-grid'
import Pagination from '@/components/product/pagination'
import { useQuery } from '@tanstack/react-query'
import { getMedusaClient } from '@/lib/medusa-client'
import PorchPage from '@/components/porch/porch-page'
import { Sticker, StringLights } from '@/components/porch/decor'
import { eyebrow, pageTitle, wrap } from '@/components/porch/ui'

const PAGE_SIZE = 16

const chip =
  'min-h-11 rounded-full border-2 border-border px-5 py-2 text-sm font-black transition-colors hover:bg-muted aria-[current=true]:bg-foreground aria-[current=true]:text-background'

function ProductsPageContent() {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const selectedCategory = searchParams.get('category') || ''
  const sortBy = searchParams.get('sort') || 'newest'
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10) || 1)

  const [result, setResult] = useState<{ count: number; loading: boolean }>({ count: 0, loading: true })

  const gridRef = useRef<HTMLDivElement>(null)

  const updateParams = (updates: Record<string, string | null>) => {
    const params = new URLSearchParams(searchParams.toString())
    for (const [key, value] of Object.entries(updates)) {
      if (!value) params.delete(key)
      else params.set(key, value)
    }
    router.replace(`${pathname}?${params.toString()}`, { scroll: false })
  }

  const handleCategoryChange = (categoryId: string) => {
    updateParams({ category: categoryId || null, page: null })
  }

  const handleSortChange = (sort: string) => {
    updateParams({ sort: sort === 'newest' ? null : sort, page: null })
  }

  const handlePageChange = (nextPage: number) => {
    updateParams({ page: nextPage > 1 ? String(nextPage) : null })
    gridRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  const totalPages = Math.max(1, Math.ceil(result.count / PAGE_SIZE))

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const response = await getMedusaClient().store.category.list({ limit: 100 })
      return response.product_categories
    },
  })

  const allCategories = categories || []

  return (
    <PorchPage>
      {/* The URL state is the contract this page shares with the rest of the storefront:
          `?category=`, `?sort=` and `?page=`. Keep the handlers wired, keep ProductGrid and
          Pagination. */}
      <section className="relative overflow-hidden border-b-2 border-border bg-muted">
        <StringLights onLight className="absolute inset-x-0 top-0" />
        <div className={`${wrap} relative flex flex-col gap-7 pb-10 pt-20 sm:flex-row sm:items-end sm:justify-between sm:pb-12`}>
          <div>
            <p className={eyebrow}>Fresh from the porch</p>
            <h1 className={`${pageTitle} mt-3`}>Shop all tees</h1>
            <p className="mt-4 min-h-5 text-xs font-extrabold uppercase tracking-[0.12em] text-accent" aria-live="polite">
              {result.loading ? '' : `${result.count} punny designs`}
            </p>
          </div>

          <div className="relative z-10">
            <label htmlFor="products-sort" className="mb-2 block text-xs font-black uppercase tracking-[0.14em]">Sort</label>
            <div className="relative w-fit">
              <select
                id="products-sort"
                value={sortBy}
                onChange={(e) => handleSortChange(e.target.value)}
                className="min-h-11 appearance-none rounded-full border-2 border-border bg-background py-2.5 pl-5 pr-12 text-sm font-black"
              >
                <option value="newest">Newest</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="name">Name: A to Z</option>
              </select>
              <ChevronDown aria-hidden size={18} strokeWidth={2.6} className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2" />
            </div>
          </div>
        </div>
        <Sticker name="pumpkin-wink" float="b" className="absolute -bottom-2 right-[38%] hidden h-24 w-auto lg:block" />
      </section>

      <div className={`${wrap} py-12 sm:py-16`}>
        {allCategories.length > 0 && (
          <nav aria-label="Product categories" className="mb-10 flex flex-wrap items-center gap-2">
            <ul className="flex flex-wrap gap-2">
              <li>
                <button onClick={() => handleCategoryChange('')} aria-current={!selectedCategory} className={chip}>
                  All Products
                </button>
              </li>
              {allCategories.map((category: any) => (
                <li key={category.id}>
                  <button
                    onClick={() => handleCategoryChange(category.id)}
                    aria-current={selectedCategory === category.id}
                    className={chip}
                  >
                    {category.name}
                  </button>
                </li>
              ))}
            </ul>
            {selectedCategory && (
              <button onClick={() => handleCategoryChange('')} className="min-h-11 px-3 text-sm font-black text-primary underline underline-offset-4">
                Clear filters
              </button>
            )}
          </nav>
        )}

        <div ref={gridRef} className="scroll-mt-28">
          <ProductGrid
            categoryId={selectedCategory || undefined}
            sortBy={sortBy}
            page={page}
            pageSize={PAGE_SIZE}
            onResult={setResult}
          />
          <Pagination page={page} totalPages={totalPages} onPageChange={handlePageChange} />
        </div>
      </div>
    </PorchPage>
  )
}

export default function ProductsPage() {
  return (
    <Suspense fallback={null}>
      <ProductsPageContent />
    </Suspense>
  )
}

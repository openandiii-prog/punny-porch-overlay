'use client'

import { useCart } from '@/hooks/use-cart'
import Link from 'next/link'
import { formatPrice } from '@/lib/utils/format-price'
import { useOrderTotals } from '@/hooks/use-order-totals'
import { CartLineItemCard } from '@/components/cart/cart-line-item-card'
import { PromoCodeInput } from '@/components/checkout/promo-code-input'
import { isSubscriptionCart } from '@/lib/subscription-cart'
import type { CartLineItem } from '@/types'
import PorchPage from '@/components/porch/porch-page'
import { Sticker } from '@/components/porch/decor'
import { eyebrow, pageTitle, pill, pillGhost, wrap } from '@/components/porch/ui'

const row = 'flex items-baseline justify-between gap-4'

/**
 * Dedicated cart page, the full-page counterpart to the cart drawer. Same
 * hooks (`useCart`), zero new commerce logic: shared item components (see
 * CartLineItemCard) plus the order summary. The drawer stays the
 * quick-glance surface; this page is the considered-review surface and links
 * straight into checkout.
 *
 * Nothing on this page moves and nothing decorates the money: the one sticker
 * only appears when the bag is empty.
 */
export default function CartPage() {
  const {
    cart,
    isLoading,
    discountTotal,
    appliedPromoCodes,
    applyPromoCode,
    removePromoCode,
    isApplyingPromo,
    isRemovingPromo,
    updateItem,
    removeItem,
    isUpdatingItem,
    updatingItemId,
    isRemovingItem,
    removingItemId,
  } = useCart()

  const currencyCode = cart?.currency_code || cart?.region?.currency_code || 'usd'
  const items: CartLineItem[] = cart?.items ?? []
  const { subtotal, shippingLabel, taxTotal, isTaxInclusive, total } = useOrderTotals({
    cart,
    discountTotal,
  })

  return (
    <PorchPage calm>
      {/* THE MONEY LADDER IS NOT DECORATION. Subtotal, Discounts, Shipping, Tax and
          Total must ALL stay rendered, in this order, with the same wording as
          checkout's OrderSummary. `total` already includes shipping and tax, so
          dropping those rows leaves a buyer returning from checkout looking at
          a total nothing accounts for. Restyle the rows; never remove one.

          Also keep: CartLineItemCard (shared with the drawer), PromoCodeInput
          and its `isSubscriptionCart` guard (the server rejects a promo on a
          subscription cart), and both the /checkout and /products links. */}
      <div className={`${wrap} py-10 sm:py-14`}>
        <p className={eyebrow}>Your bag</p>
        <h1 className={`${pageTitle} mt-3`}>{items.length > 0 ? 'Review Your Items' : 'Your Cart'}</h1>

        {isLoading ? (
          <p className="mt-10 font-bold text-muted-foreground">Loading your cart…</p>
        ) : items.length === 0 ? (
          <div className="mt-10 flex flex-col items-center rounded-[36px_36px_36px_12px] border-2 border-border bg-muted px-6 py-14 text-center">
            <Sticker name="ghost-empty-bag" className="mb-6 h-36 w-auto" />
            <p className="font-heading text-3xl">Your cart is empty.</p>
            <Link href="/products" prefetch={true} className={`${pill} mt-7`}>Start Shopping</Link>
          </div>
        ) : (
          <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_380px] lg:items-start lg:gap-14">
            <ul className="divide-y-2 divide-border/15 border-y-2 border-border">
              {items.map((item) => (
                <li key={item.id} className="py-6">
                  <CartLineItemCard
                    item={item}
                    currencyCode={currencyCode}
                    variant="page"
                    isUpdating={isUpdatingItem && updatingItemId === item.id}
                    isRemoving={isRemovingItem && removingItemId === item.id}
                    onUpdateQuantity={(quantity) => updateItem({ lineId: item.id, quantity })}
                    onRemove={() => removeItem(item.id)}
                  />
                </li>
              ))}
            </ul>

            <aside className="rounded-[30px] border-2 border-border bg-background p-6 shadow-[8px_9px_0_hsl(var(--accent))] sm:p-7 lg:sticky lg:top-28">
              <h2 className="font-heading text-3xl leading-none">Order Summary</h2>
              <dl className="mt-6 space-y-3 text-sm font-bold">
                <div className={row}>
                  <dt>Subtotal</dt>
                  <dd>{formatPrice(subtotal, currencyCode)}</dd>
                </div>

                {discountTotal > 0 && (
                  <div className={`${row} text-primary`}>
                    <dt>Discounts</dt>
                    <dd>-{formatPrice(discountTotal, currencyCode)}</dd>
                  </div>
                )}

                <div className={row}>
                  <dt>Shipping</dt>
                  <dd className="text-right text-muted-foreground">{shippingLabel ?? 'Calculated at checkout'}</dd>
                </div>

                {taxTotal > 0 && (
                  <div className={row}>
                    <dt>{isTaxInclusive ? 'Includes tax' : 'Tax'}</dt>
                    <dd>
                      {isTaxInclusive ? '' : '+'}
                      {formatPrice(taxTotal, currencyCode)}
                    </dd>
                  </div>
                )}

                <div className={`${row} border-t-2 border-border pt-4 text-base`}>
                  <dt className="font-black uppercase tracking-[0.1em]">Total</dt>
                  <dd className="font-heading text-3xl tracking-tight">{formatPrice(total, currencyCode)}</dd>
                </div>
              </dl>

              {!shippingLabel && (
                <p className="mt-3 text-sm text-muted-foreground">Shipping and taxes calculated at checkout.</p>
              )}

              {!isSubscriptionCart(cart) && (
                <div className="mt-5">
                  <PromoCodeInput
                    appliedPromoCodes={appliedPromoCodes}
                    discountTotal={discountTotal}
                    currencyCode={currencyCode}
                    isApplyingPromo={isApplyingPromo}
                    isRemovingPromo={isRemovingPromo}
                    onApply={applyPromoCode}
                    onRemove={removePromoCode}
                  />
                </div>
              )}

              <div className="mt-6 flex flex-col gap-3">
                <Link href="/checkout" prefetch={true} className={`${pill} w-full`}>Checkout</Link>
                <Link href="/products" prefetch={true} className={`${pillGhost} w-full`}>Continue shopping</Link>
              </div>
            </aside>
          </div>
        )}
      </div>
    </PorchPage>
  )
}

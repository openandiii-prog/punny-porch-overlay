import PorchPage from '@/components/porch/porch-page'
import { BandSkeleton, GridSkeleton } from '@/components/porch/page-parts'
import { wrap } from '@/components/porch/ui'

// Loading state shaped like a collection page.
export default function CollectionDetailLoading() {
  return (
    <PorchPage>
      <BandSkeleton />
      <div className={`${wrap} py-12 sm:py-16`}>
        <GridSkeleton count={8} />
      </div>
    </PorchPage>
  )
}

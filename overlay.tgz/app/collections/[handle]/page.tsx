import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { medusaServerClient } from '@/lib/medusa-client'
import CollectionProducts from '@/components/collection/collection-products'
import { PluginSlot } from '@/components/PluginSlot'
import {
  applyContentMetadata,
  getSeoDescription,
  getSeoTitle,
} from '@/lib/utils/content-metadata'
import PorchPage from '@/components/porch/porch-page'
import { PageBand } from '@/components/porch/page-parts'
import { wrap } from '@/components/porch/ui'

async function getCollection(handle: string) {
  try {
    const response = await medusaServerClient.store.collection.list({
      handle: [handle],
      fields: '+metadata',
    })
    const collection = response.collections?.[0]
    return collection ? applyContentMetadata(collection, 'Collection') : null
  } catch (error) {
    console.error('Error fetching collection:', error)
    return null
  }
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ handle: string }>
}): Promise<Metadata> {
  const { handle } = await params
  const collection = await getCollection(handle)

  if (!collection) {
    return {
      title: 'Collection Not Found',
      robots: { index: false, follow: false },
    }
  }

  const title = getSeoTitle(collection, 'Collection')
  const description =
    getSeoDescription(collection) || 'Browse our latest products in this collection.'
  const canonicalPath = `/collections/${collection.handle || handle}`

  return {
    title: { absolute: title },
    description,
    alternates: { canonical: canonicalPath },
    openGraph: {
      type: 'website',
      title,
      description,
      url: canonicalPath,
    },
  }
}

export default async function CollectionPage({
  params,
}: {
  params: Promise<{ handle: string }>
}) {
  const { handle } = await params
  const collection = await getCollection(handle)

  if (!collection) {
    notFound()
  }

  const description = collection.metadata?.description
  const hasDescription = typeof description === 'string' && description

  return (
    <PorchPage>
      {/* Both PluginSlot tags must survive with their `context` intact and render
          UNCONDITIONALLY. `CollectionProducts` is the grid: restyle it, never replace it. */}
      <PageBand eyebrow="The collection" title={collection.title}>
        {hasDescription && <p className="mt-4 max-w-xl leading-7 text-muted-foreground">{description as string}</p>}
      </PageBand>

      <div className={`${wrap} py-12 sm:py-16`}>
        <Link
          href="/collections"
          className="mb-8 inline-flex min-h-11 items-center gap-2 text-xs font-black uppercase tracking-[0.14em] text-accent transition-colors hover:text-primary"
        >
          ← Collections
        </Link>
        {/* Filter enhancements, promo banners */}
        <PluginSlot
          name="collectionAboveGrid"
          context={{ collectionId: collection.id, collectionTitle: collection.title }}
        />
        <CollectionProducts collectionId={collection.id} />
        {/* Load-more extensions, banners */}
        <PluginSlot name="collectionBelowGrid" context={{ collectionId: collection.id }} />
      </div>
    </PorchPage>
  )
}

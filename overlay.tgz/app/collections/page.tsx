import { medusaServerClient } from '@/lib/medusa-client'
import Link from 'next/link'
import { Metadata } from 'next'
import {
  applyContentMetadata,
  type ContentCollection,
} from '@/lib/utils/content-metadata'
import PorchPage from '@/components/porch/porch-page'
import { PageBand } from '@/components/porch/page-parts'
import ProductGrid from '@/components/product/product-grid'
import { pill, sectionTitle, wrap } from '@/components/porch/ui'

export const metadata: Metadata = { title: 'Collections' }

async function getCollections() {
  try {
    const response = await medusaServerClient.store.collection.list({
      limit: 50,
      fields: '+metadata',
    })
    return ((response.collections || []) as ContentCollection[]).map((collection) =>
      applyContentMetadata(collection, 'Collection'),
    )
  } catch {
    return []
  }
}

export default async function CollectionsPage() {
  const collections = await getCollections()

  return (
    <PorchPage>
      {/* The collection links and their handles are the contract. Everything else is the look. */}
      <PageBand eyebrow="Browse" title="Collections" />

      <div className={`${wrap} py-12 sm:py-16`}>
        {collections.length === 0 ? (
          // No collections set up yet: say so, then show every tee so this page is never a dead end.
          <>
            <div className="mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="font-bold text-muted-foreground">No collections available yet.</p>
                <h2 className={`${sectionTitle} mt-2`}>Pick your pun.</h2>
              </div>
              <Link href="/products" className={pill}>Shop all tees</Link>
            </div>
            <ProductGrid limit={24} />
          </>
        ) : (
          <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {collections.map((collection: any) => {
              const description =
                typeof collection.metadata?.description === 'string'
                  ? collection.metadata.description
                  : null

              return (
                <li key={collection.id}>
                  <Link
                    href={`/collections/${collection.handle}`}
                    className="group flex h-full min-h-48 flex-col justify-between rounded-[30px_30px_30px_10px] border-2 border-border bg-muted p-7 shadow-[6px_7px_0_hsl(var(--accent))] transition-transform hover:-translate-y-1"
                  >
                    <div>
                      <h2 className="font-heading text-4xl leading-none tracking-[-0.04em]">{collection.title}</h2>
                      {description && <p className="mt-3 leading-7 text-muted-foreground">{description}</p>}
                    </div>
                    <span className="mt-6 text-sm font-black uppercase tracking-[0.12em] text-primary">Shop the tees</span>
                  </Link>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </PorchPage>
  )
}

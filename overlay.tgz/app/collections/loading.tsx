import PorchPage from '@/components/porch/porch-page'
import { BandSkeleton } from '@/components/porch/page-parts'
import { wrap } from '@/components/porch/ui'

// Loading state shaped like the collections index.
export default function CollectionsLoading() {
  return (
    <PorchPage>
      <BandSkeleton />
      <div aria-hidden className={`${wrap} grid gap-6 py-12 sm:grid-cols-2 sm:py-16 lg:grid-cols-3`}>
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-48 animate-pulse rounded-[30px_30px_30px_10px] bg-muted" />
        ))}
      </div>
    </PorchPage>
  )
}

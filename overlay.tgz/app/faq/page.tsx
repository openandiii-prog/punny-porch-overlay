import { Metadata } from 'next'
import Link from 'next/link'
import PorchPage from '@/components/porch/porch-page'
import { Sticker } from '@/components/porch/decor'
import { PageBand } from '@/components/porch/page-parts'
import { pillGhost, wrap } from '@/components/porch/ui'
import { FaqAccordion } from './faq-accordion'

// NEVER invent policy answers here: they render as the merchant's own claims. Every answer
// below is taken word for word from the details the store already publishes on each product
// listing (fit, fabric, care, production time, colors, how the art is made). Returns and
// refunds are deliberately absent until the store has a refund policy configured.

export const metadata: Metadata = {
  title: 'FAQ',
  description: 'Frequently asked questions about orders, shipping, returns, and more.',
}

const FAQS = [
  {
    q: 'How do the tees fit?',
    a: 'Unisex sizing runs roomy. For a fitted look, size down one. For the oversized look in the photos, size up one or two.',
  },
  {
    q: 'What are the tees made of?',
    a: 'Comfort Colors 1717 garment-dyed heavyweight tee, 100% ring-spun cotton. Relaxed unisex fit, soft lived-in feel from day one.',
  },
  {
    q: 'How long does an order take?',
    a: 'Each shirt is printed to order, usually 2 to 5 business days to produce plus shipping time.',
  },
  {
    q: 'How do I wash my tee?',
    a: 'Machine wash cold inside out, tumble dry low or hang dry. Do not iron directly on the design.',
  },
  {
    q: 'What colors do the tees come in?',
    a: 'Every design comes in Ivory and Pepper.',
  },
  {
    q: 'Who makes the art?',
    a: 'Artwork designed by our shop with the help of AI design tools, printed to order by our production partner.',
  },
]

export default function FaqPage() {
  return (
    <PorchPage>
      <PageBand eyebrow="Good to know" title="Frequently Asked Questions" />

      <div className={`${wrap} grid gap-12 py-14 sm:py-20 lg:grid-cols-[1.4fr_0.6fr] lg:gap-16`}>
        <div className="rounded-[30px] border-2 border-border bg-background px-6 py-2 shadow-[8px_9px_0_hsl(var(--accent))] sm:px-9">
          <FaqAccordion faqs={FAQS} />
        </div>

        <aside className="flex flex-col items-start">
          <Sticker name="cocoa-mug" float="c" className="mb-6 h-32 w-auto" />
          <h2 className="font-heading text-3xl leading-none">Still have a question?</h2>
          <Link href="/contact" className={`${pillGhost} mt-6`}>Contact Us</Link>
        </aside>
      </div>
    </PorchPage>
  )
}

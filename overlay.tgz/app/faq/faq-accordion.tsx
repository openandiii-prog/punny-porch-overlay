'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="border-b-2 border-border/15 last:border-b-0">
      <button
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        className="flex min-h-16 w-full items-center justify-between gap-4 py-4 text-left"
      >
        <span className="font-heading text-xl leading-tight sm:text-2xl">{q}</span>
        <ChevronDown
          aria-hidden
          data-open={open}
          size={22}
          strokeWidth={2.8}
          className="shrink-0 text-primary data-[open=true]:rotate-180"
        />
      </button>
      <div data-open={open} hidden={!open} className="pb-6 pr-10">
        <p className="leading-7 text-muted-foreground">{a}</p>
      </div>
    </div>
  )
}

// The panel really collapses with `hidden={!open}`, so it works with no styling at all.
// `data-open` is on both the chevron and the panel. Keep the toggle and `hidden`.
export function FaqAccordion({ faqs }: { faqs: { q: string; a: string }[] }) {
  return (
    <>
      {faqs.map((faq, i) => <FaqItem key={i} {...faq} />)}
    </>
  )
}

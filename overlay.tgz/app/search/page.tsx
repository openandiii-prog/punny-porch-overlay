'use client'

import { useState } from 'react'
import { Search as SearchIcon } from 'lucide-react'
import ProductGrid from '@/components/product/product-grid'
import { ClientPluginSlot } from '@/components/ClientPluginSlot'
import PorchPage from '@/components/porch/porch-page'
import { Sticker } from '@/components/porch/decor'
import { PageBand } from '@/components/porch/page-parts'
import { wrap } from '@/components/porch/ui'

// Keep the query wiring, the empty state and both plugin slot tags.
export default function SearchPage() {
  const [query, setQuery] = useState('')

  return (
    <PorchPage>
      <PageBand eyebrow="Search" title="Pick your pun.">
        <div className="relative mt-7 max-w-xl">
          <SearchIcon aria-hidden size={20} strokeWidth={2.6} className="pointer-events-none absolute left-5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products..."
            aria-label="Search products"
            autoFocus
            className="min-h-14 w-full rounded-full border-2 border-border bg-background py-3 pl-14 pr-6 text-base font-bold shadow-[4px_5px_0_hsl(var(--foreground))] placeholder:font-normal placeholder:text-muted-foreground"
          />
        </div>
      </PageBand>

      <div className={`${wrap} py-12 sm:py-16`}>
        {query ? (
          <>
            <p className="mb-8 text-sm font-bold text-muted-foreground">
              Showing results for &ldquo;{query}&rdquo;
            </p>
            {/* Search ads, filter enhancements */}
            <ClientPluginSlot name="searchAboveResults" context={{ query }} />
            <ProductGrid limit={20} query={query} />
          </>
        ) : (
          <div className="flex flex-col items-center py-10 text-center">
            <Sticker name="ghost-lost" float="a" className="mb-6 h-36 w-auto" />
            <p className="font-heading text-3xl">Start typing to search products</p>
          </div>
        )}
      </div>
    </PorchPage>
  )
}

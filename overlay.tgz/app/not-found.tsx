import Link from 'next/link'
import PorchPage from '@/components/porch/porch-page'
import { Sticker } from '@/components/porch/decor'
import { eyebrow, pageTitle, pill, pillGhost, wrap } from '@/components/porch/ui'

// A 404 is part of the store and looks like it. Keep both links.
export default function NotFound() {
  return (
    <PorchPage>
      <div className={`${wrap} flex flex-col items-center py-16 text-center sm:py-24`}>
        <Sticker name="ghost-lost" float="a" className="mb-8 h-44 w-auto" />
        <p className={eyebrow}>404</p>
        <h1 className={`${pageTitle} mt-3`}>Page Not Found</h1>
        <p className="mt-5 max-w-md leading-7 text-muted-foreground">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/" className={pill}>
            Go Home
          </Link>
          <Link href="/products" className={pillGhost}>
            Shop All
          </Link>
        </div>
      </div>
    </PorchPage>
  )
}

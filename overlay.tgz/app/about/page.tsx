import { Metadata } from 'next'
import Link from 'next/link'
import PorchPage from '@/components/porch/porch-page'
import { Sticker } from '@/components/porch/decor'
import { PageBand } from '@/components/porch/page-parts'
import ProductGrid from '@/components/product/product-grid'
import { eyebrow, pill, sectionTitle, wrap } from '@/components/porch/ui'

// NEVER invent brand claims here (founding year, sourcing, guarantees): they render as the
// merchant's own statements. Every sentence on this page is taken from copy the store already
// publishes on its home page and product listings. New facts need the owner's say-so first.

export const metadata: Metadata = { title: 'About Us' }

const FACTS = [
  {
    title: 'Made to order',
    body: 'Each shirt is printed to order, usually 2 to 5 business days to produce plus shipping time.',
  },
  {
    title: 'The tee',
    body: 'Comfort Colors 1717 garment-dyed heavyweight tee, 100% ring-spun cotton. Relaxed unisex fit, soft lived-in feel from day one.',
  },
  {
    title: 'The art',
    body: 'Artwork designed by our shop with the help of AI design tools, printed to order by our production partner.',
  },
] as const

export default function AboutPage() {
  return (
    <PorchPage>
      <PageBand eyebrow="Our porch" title="About Us">
        <p className="mt-5 max-w-xl text-lg leading-8 text-muted-foreground">
          Cozy punny Halloween tees for the moms who bring the good candy.
        </p>
      </PageBand>

      <div className={`${wrap} py-14 sm:py-20`}>
        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center lg:gap-16">
          <div className="relative">
            <p className={eyebrow}>The porch promise</p>
            <h2 className={`${sectionTitle} mt-3`}>
              Halloween joy,<br /><span className="text-primary">zero creepy.</span>
            </h2>
            <p className="mt-6 max-w-md text-lg leading-8 text-muted-foreground">
              We make the kind of tees that earn a grin in the school pick-up line and make your annual porch photo even better.
            </p>
            <Sticker name="black-cat" float="b" className="mt-8 h-32 w-auto" />
          </div>

          <ul className="grid gap-5">
            {FACTS.map((fact, index) => (
              <li
                key={fact.title}
                className="rounded-[30px_30px_30px_10px] border-2 border-border bg-muted p-6 shadow-[6px_7px_0_hsl(var(--accent))] sm:p-7"
              >
                <p className="font-heading text-2xl text-primary">0{index + 1}</p>
                <h3 className="mt-1 font-heading text-3xl leading-none">{fact.title}</h3>
                <p className="mt-3 leading-7 text-muted-foreground">{fact.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <section className="border-t-2 border-border bg-muted">
        <div className={`${wrap} py-14 sm:py-16`}>
          <div className="mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className={eyebrow}>Fresh from the porch</p>
              <h2 className={`${sectionTitle} mt-2`}>Pick your pun.</h2>
            </div>
            <Link href="/products" className={pill}>Shop all tees</Link>
          </div>
          <ProductGrid limit={4} />
        </div>
      </section>
    </PorchPage>
  )
}

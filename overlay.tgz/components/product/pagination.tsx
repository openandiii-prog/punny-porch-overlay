'use client'

import { ChevronLeft, ChevronRight } from 'lucide-react'

interface PaginationProps {
  page: number
  totalPages: number
  onPageChange: (page: number) => void
}

function pageWindow(page: number, totalPages: number): (number | 'ellipsis')[] {
  const pages: (number | 'ellipsis')[] = []
  const add = (p: number) => pages.push(p)

  add(1)
  if (page > 3) pages.push('ellipsis')
  for (let p = Math.max(2, page - 1); p <= Math.min(totalPages - 1, page + 1); p++) add(p)
  if (page < totalPages - 2) pages.push('ellipsis')
  if (totalPages > 1) add(totalPages)

  return pages
}

const pageButton =
  'grid size-11 place-items-center rounded-full border-2 border-border text-sm font-black transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:border-border/25 disabled:text-muted-foreground disabled:hover:bg-transparent data-[current=true]:bg-foreground data-[current=true]:text-background'

// The active page carries `data-current`. Keep the page maths and the handlers.
export default function Pagination({ page, totalPages, onPageChange }: PaginationProps) {
  if (totalPages <= 1) return null

  return (
    <nav aria-label="Pagination" className="mt-14 flex flex-wrap items-center justify-center gap-2">
      <button
        onClick={() => onPageChange(page - 1)}
        disabled={page <= 1}
        aria-label="Previous page"
        className={pageButton}
      >
        <ChevronLeft size={18} strokeWidth={2.6} />
      </button>

      {pageWindow(page, totalPages).map((p, i) =>
        p === 'ellipsis' ? (
          <span key={`e${i}`} className="px-1 font-black text-muted-foreground">
            …
          </span>
        ) : (
          <button
            key={p}
            onClick={() => onPageChange(p)}
            aria-current={p === page ? 'page' : undefined}
            data-current={p === page}
            className={pageButton}
          >
            {p}
          </button>
        ),
      )}

      <button
        onClick={() => onPageChange(page + 1)}
        disabled={page >= totalPages}
        aria-label="Next page"
        className={pageButton}
      >
        <ChevronRight size={18} strokeWidth={2.6} />
      </button>
    </nav>
  )
}

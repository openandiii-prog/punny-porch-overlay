import Image from 'next/image'
import Link from 'next/link'
import { getProductImage } from '@/lib/utils/placeholder-images'
import ProductPrice, { isProductSoldOut, type VariantExtension } from './product-price'
import { ClientPluginSlot } from '@/components/ClientPluginSlot'

interface ProductCardProps {
  product: any
  variantExtensions?: Record<string, VariantExtension>
}

// Same card the home page uses for its featured tees: a 4:5 photo, the name, the price.
// No decoration lives in here on purpose, so the tee photo does all the talking.
//
// MUST SURVIVE any restyle: the `collectionCard` ClientPluginSlot with its `context`,
// rendered unconditionally; the `{ product` destructure in this component's signature
// (the plugin codemod looks for that literal); ProductPrice (compare-at strikethrough and
// sold-out handling live in it); and the `/products/${product.handle}` link.
export default function ProductCard({ product, variantExtensions }: ProductCardProps) {
  const variant = product.variants?.[0]
  const calculatedPrice = variant?.calculated_price

  const currency = calculatedPrice?.currency_code || 'usd'
  const currentAmount = calculatedPrice?.calculated_amount
  const ext = variant?.id ? variantExtensions?.[variant.id] : null

  const soldOut = isProductSoldOut(product.variants || [], variantExtensions)

  return (
    <Link href={`/products/${product.handle}`} prefetch={true} className="group block">
      <div className="relative aspect-[4/5] overflow-hidden rounded-[30px] bg-muted">
        <Image
          src={getProductImage(product.thumbnail, product.id)}
          alt={product.title}
          width={800}
          height={1000}
          sizes="(max-width: 1024px) 50vw, 25vw"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]"
        />
        {soldOut && (
          <span className="absolute left-3 top-3 z-10 rounded-full bg-foreground px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-background">
            Sold Out
          </span>
        )}
      </div>

      <div className="mt-4 flex items-start gap-2">
        <h3 className="flex-1 text-sm font-black leading-5 sm:text-base">{product.title}</h3>
        <ProductPrice
          amount={currentAmount}
          currency={currency}
          compareAtPrice={ext?.compare_at_price}
          soldOut={soldOut}
          size="card"
        />
      </div>
      {/* Review stars on card, wishlist heart */}
      <ClientPluginSlot
        name="collectionCard"
        context={{ productId: product.id, productName: product.title }}
      />
    </Link>
  )
}

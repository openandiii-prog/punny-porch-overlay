'use client'

import { useEffect } from 'react'
import { useProducts } from '@/hooks/use-products'
import { useAllProducts } from '@/hooks/use-all-products'
import { getProductSortStrategy, useProductSort } from '@/hooks/use-product-sort'
import { useQuery } from '@tanstack/react-query'
import ProductCard from './product-card'
import type { Product } from '@/types'
import { pill } from '@/components/porch/ui'

const GRID = 'grid grid-cols-2 gap-x-4 gap-y-9 md:grid-cols-3 lg:grid-cols-4 lg:gap-x-6'

interface ProductGridProps {
  limit?: number
  collectionId?: string
  categoryId?: string
  sortBy?: string
  query?: string
  page?: number
  pageSize?: number
  onResult?: (info: { count: number; loading: boolean }) => void
}

function ProductSkeleton() {
  // Same shape as ProductCard, so nothing jumps when the tees arrive.
  return (
    <div aria-hidden>
      <div className="aspect-[4/5] animate-pulse rounded-[30px] bg-muted" />
      <div className="mt-4 h-4 w-3/4 animate-pulse rounded-full bg-muted" />
    </div>
  )
}

export default function ProductGrid({
  limit = 8,
  collectionId,
  categoryId,
  sortBy = 'newest',
  query,
  page = 1,
  pageSize,
  onResult,
}: ProductGridProps) {
  const { paginated, serverOrder, canDirectFetch, effectiveLimit } = getProductSortStrategy(
    sortBy,
    limit,
    pageSize,
  )

  const {
    data: pageData,
    isLoading: pageLoading,
    error: pageError,
  } = useProducts({
    limit: effectiveLimit,
    offset: paginated && canDirectFetch ? (page - 1) * effectiveLimit : 0,
    order: paginated ? serverOrder : undefined,
    collection_id: collectionId,
    category_id: categoryId,
    q: query,
    enabled: canDirectFetch,
  })

  const {
    data: allData,
    isLoading: allLoading,
    error: allError,
  } = useAllProducts({
    collection_id: collectionId,
    category_id: categoryId,
    q: query,
    enabled: !canDirectFetch,
  })

  const isLoading = canDirectFetch ? pageLoading : allLoading
  const error = canDirectFetch ? pageError : allError
  const rawProducts = canDirectFetch ? pageData?.products : allData?.products
  const truncated = !canDirectFetch && !!allData?.truncated

  const productIds = rawProducts?.map((p: Product) => p.id) || []
  const { data: variantExtensions } = useQuery({
    queryKey: ['variant-extensions', productIds],
    queryFn: async () => {
      const baseUrl = process.env.NEXT_PUBLIC_MEDUSA_BACKEND_URL || 'http://localhost:9000'
      const storeId = process.env.NEXT_PUBLIC_STORE_ID
      const publishableKey = process.env.NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY
      const headers: Record<string, string> = { 'Content-Type': 'application/json' }
      if (storeId) headers['X-Store-Environment-ID'] = storeId
      if (publishableKey) headers['x-publishable-api-key'] = publishableKey

      try {
        const res = await fetch(
          `${baseUrl}/store/product-extensions/variants/batch`,
          {
            method: 'POST',
            headers,
            body: JSON.stringify({ product_ids: productIds }),
          },
        )
        if (!res.ok) return {}
        const data = await res.json()
        const results: Record<string, { compare_at_price: number | null; allow_backorder: boolean; inventory_quantity: number | null }> = {}
        for (const v of data.variants || []) {
          results[v.id] = {
            compare_at_price: v.compare_at_price,
            allow_backorder: v.allow_backorder ?? false,
            inventory_quantity: v.inventory_quantity,
          }
        }
        return results
      } catch {
        return {}
      }
    },
    enabled: productIds.length > 0,
    staleTime: 1000 * 60 * 5,
  })

  const { products, total } = useProductSort(rawProducts, sortBy, page, pageSize, pageData?.count)

  useEffect(() => {
    onResult?.({ count: total, loading: isLoading })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [total, isLoading])

  // The grid look is ours. What is NOT: the sort strategy, the pagination contract, the
  // variantExtensions fetch and the empty/error branches below. Every branch keeps rendering
  // something, or a failed load would look like an empty store.
  if (isLoading) {
    return (
      <div className={GRID}>
        {Array.from({ length: pageSize || limit }).map((_, i) => (
          <ProductSkeleton key={i} />
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <div className="rounded-[30px] border-2 border-border bg-muted px-6 py-12 text-center">
        <p className="font-bold">{error instanceof Error ? error.message : 'Failed to load products'}</p>
        <button onClick={() => window.location.reload()} className={`${pill} mt-6`}>Try again</button>
      </div>
    )
  }

  if (!products || products.length === 0) {
    return (
      <p className="rounded-[30px] border-2 border-dashed border-border/40 px-6 py-14 text-center font-bold text-muted-foreground">
        No products available yet
      </p>
    )
  }

  return (
    <>
      {truncated && (
        <p className="mb-6 rounded-2xl bg-muted px-4 py-3 text-sm font-bold text-muted-foreground">
          Showing the first {rawProducts?.length ?? 0} of {allData?.count} products for this sort
          order. Narrow your search or category to see the rest.
        </p>
      )}
      <div className={GRID}>
        {products.map((product: Product) => (
          <ProductCard key={product.id} product={product} variantExtensions={variantExtensions} />
        ))}
      </div>
    </>
  )
}

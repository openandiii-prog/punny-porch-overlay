'use client'

import { useRef, useState } from 'react'
import { useCart } from '@/hooks/use-cart'
import { useVariantSelection, type ProductVariantWithPrice } from '@/hooks/use-variant-selection'
import { useSubscriptionCart } from '@/hooks/use-subscription-cart'
import { Minus, Plus, Check, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import ProductPrice, { type VariantExtension } from './product-price'
import SubscriptionSelector, { type PurchaseType } from './subscription-selector'
import { trackAddToCart } from '@/lib/analytics'
import { openCartDrawer } from '@/lib/cart-ui'
import type { Product } from '@/types'
import type { WithSubscription } from '@/hooks/use-subscription-offers'

interface ProductActionsProps {
  product: Product
  variantExtensions?: Record<string, VariantExtension>
}

interface ProductOptionValue {
  id?: string
  value: string
}

interface ProductOptionWithValues {
  id: string
  title: string
  values?: (string | ProductOptionValue)[]
}

function getVariantPriceAmount(variant: ProductVariantWithPrice | undefined): number | null {
  const cp = variant?.calculated_price
  if (!cp) return null
  return typeof cp === 'number' ? cp : cp.calculated_amount ?? null
}

// The catalog hands sizes back in creation order (S came last), so put the garment ladder back.
// Values that are not sizes (colors) all rank the same, and the sort is stable, so they keep their order.
const SIZE_LADDER = ['XXS', 'XS', 'S', 'M', 'L', 'XL', '2XL', '3XL', '4XL', '5XL']
const sizeRank = (value: string) => {
  const i = SIZE_LADDER.indexOf(value.toUpperCase())
  return i < 0 ? SIZE_LADDER.length : i
}

export default function ProductActions({ product, variantExtensions }: ProductActionsProps) {
  const options = product.options || []
  const {
    hasMultipleVariants,
    selectedOptions,
    setSelectedOption,
    selectedVariant,
    variantExtension: ext,
    inventoryQuantity,
    isOutOfStock,
    isLowStock,
    maxQuantity,
    isValueAvailable,
  } = useVariantSelection(product, variantExtensions)

  const [quantity, setQuantity] = useState(1)
  const [justAdded, setJustAdded] = useState(false)
  const { addItem, isAddingItem } = useCart()
  const { addSubscriptionItem, isAddingSubscriptionItem } = useSubscriptionCart()
  const subscription = (product as WithSubscription<Product>).subscription
  const subscriptionOnly = !!subscription?.eligible && !!subscription.subscription_only
  const [purchaseType, setPurchaseType] = useState<PurchaseType>(subscriptionOnly ? 'subscription' : 'one_time')
  const [interval, setInterval] = useState<string | null>(null)
  const isSubscribing = !!subscription?.eligible && (subscriptionOnly || purchaseType === 'subscription')
  const isAddingRef = useRef(false)

  const currentPriceCents = getVariantPriceAmount(selectedVariant)
  const cp = selectedVariant?.calculated_price
  const currency = (cp && typeof cp !== 'number' ? cp.currency_code : undefined) || 'usd'

  const handleOptionChange = (optionId: string, value: string) => {
    setSelectedOption(optionId, value)
    setQuantity(1)
  }

  const isDigitalProduct = product?.metadata?.is_digital === true

  const handleAddToCart = () => {
    if (!selectedVariant?.id || isOutOfStock || isAddingRef.current) return
    isAddingRef.current = true

    if (isSubscribing) {
      addSubscriptionItem(
        {
          variantId: selectedVariant.id,
          quantity,
          interval: interval ?? subscription!.default_frequency ?? subscription!.frequencies.find((f) => f.eligible)?.value ?? 'monthly',
        },
        {
          onSuccess: () => {
            setJustAdded(true)
            openCartDrawer()
            trackAddToCart(product?.id || '', selectedVariant.id, quantity, currentPriceCents ?? undefined)
            setTimeout(() => setJustAdded(false), 2000)
          },
          onError: (error: Error) => toast.error(error.message || 'Failed to add subscription'),
          onSettled: () => { isAddingRef.current = false },
        },
      )
      return
    }

    addItem(
      { variantId: selectedVariant.id, quantity, ...(isDigitalProduct ? { requiresShipping: false } : {}) },
      {
        onSuccess: () => {
          setJustAdded(true)
          openCartDrawer()
          trackAddToCart(product?.id || '', selectedVariant.id, quantity, currentPriceCents ?? undefined)
          setTimeout(() => setJustAdded(false), 2000)
        },
        onError: (error: Error) => toast.error(error.message || 'Failed to add to bag'),
        onSettled: () => { isAddingRef.current = false },
      },
    )
  }

  return (
    <div className="mt-6 border-t-2 border-border pt-6">
      <ProductPrice amount={currentPriceCents} currency={currency} compareAtPrice={ext?.compare_at_price} soldOut={isOutOfStock} size="detail" />
      <p className="mt-2 text-sm font-bold text-muted-foreground">Original art, printed to order just for you.</p>

      <div className="mt-7 space-y-6">
        {hasMultipleVariants && options.map((option: ProductOptionWithValues) => {
          const values = (option.values || []).map((v: string | ProductOptionValue) => typeof v === 'string' ? v : v.value).filter(Boolean).sort((a, b) => sizeRank(a) - sizeRank(b)) as string[]
          if (values.length <= 1 && (values[0] === 'One Size' || values[0] === 'Default')) return null
          const optionId = option.id
          const selectedValue = selectedOptions[optionId]

          return (
            <fieldset key={optionId}>
              <legend className="mb-3 flex w-full items-center justify-between text-xs font-black uppercase tracking-[0.14em] text-foreground">
                <span>{option.title}</span>
                {selectedValue && <span className="text-accent">{selectedValue}</span>}
              </legend>
              <div className="flex flex-wrap gap-2">
                {values.map((value) => {
                  const isSelected = selectedValue === value
                  const isAvailable = isValueAvailable(optionId, value)
                  return (
                    <button
                      key={value}
                      type="button"
                      onClick={() => handleOptionChange(optionId, value)}
                      disabled={!isAvailable}
                      data-selected={isSelected}
                      data-unavailable={!isAvailable}
                      className="min-w-12 rounded-full border-2 border-border px-4 py-2.5 text-sm font-black transition-colors data-[selected=true]:border-primary data-[selected=true]:bg-primary data-[selected=true]:text-primary-foreground data-[unavailable=true]:cursor-not-allowed data-[unavailable=true]:border-border/20 data-[unavailable=true]:text-muted-foreground data-[unavailable=true]:line-through hover:border-primary"
                    >
                      {value}
                    </button>
                  )
                })}
              </div>
            </fieldset>
          )
        })}
      </div>

      <div className="mt-7"><SubscriptionSelector subscription={subscription} purchaseType={purchaseType} interval={interval} onPurchaseTypeChange={setPurchaseType} onIntervalChange={setInterval} /></div>

      <p className="mt-5 rounded-full bg-muted px-4 py-3 text-sm font-black text-accent" aria-live="polite">
        {isOutOfStock ? 'Sold out right now' : isLowStock ? `Only ${inventoryQuantity} left in stock` : 'In stock and ready for fall fun'}
      </p>

      <div className="mt-7 flex gap-3">
        <div className="flex shrink-0 items-center rounded-full border-2 border-border bg-background">
          <button type="button" onClick={() => setQuantity(Math.max(1, quantity - 1))} disabled={quantity <= 1} aria-label="Decrease quantity" className="grid size-11 place-items-center disabled:text-muted-foreground"><Minus size={17} strokeWidth={2.8} /></button>
          <span className="w-7 text-center text-sm font-black">{quantity}</span>
          <button type="button" onClick={() => setQuantity(quantity + 1)} disabled={isOutOfStock || quantity >= maxQuantity} aria-label="Increase quantity" className="grid size-11 place-items-center disabled:text-muted-foreground"><Plus size={17} strokeWidth={2.8} /></button>
        </div>
        <button
          type="button"
          onClick={handleAddToCart}
          disabled={isOutOfStock || isAddingItem || isAddingSubscriptionItem}
          data-state={isOutOfStock ? 'sold-out' : justAdded ? 'added' : 'ready'}
          className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-xs font-black uppercase tracking-[0.13em] text-primary-foreground shadow-[4px_5px_0_hsl(var(--foreground))] transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground data-[state=added]:bg-accent"
        >
          {isAddingItem || isAddingSubscriptionItem ? <Loader2 className="animate-spin" size={18} /> : justAdded ? <><Check size={18} strokeWidth={3} /> Added to bag</> : isOutOfStock ? 'Sold out' : isSubscribing ? 'Subscribe' : 'Add to bag'}
        </button>
      </div>
    </div>
  )
}

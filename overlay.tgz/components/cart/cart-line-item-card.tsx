'use client'

import Image from 'next/image'
import { Minus, Plus, Trash2, Loader2 } from 'lucide-react'
import { getProductImage } from '@/lib/utils/placeholder-images'
import { formatPrice } from '@/lib/utils/format-price'
import { SubscriptionLineBadge } from '@/components/cart/subscription-line-badge'
import { isSubscriptionLine } from '@/lib/subscription-cart'
import type { CartLineItem } from '@/types'

interface CartLineItemCardProps {
  item: CartLineItem
  currencyCode: string
  /** 'page' is the roomier /cart card; 'drawer' is the compact slide-in card. */
  variant: 'page' | 'drawer'
  /** True while THIS item's quantity update is in flight. */
  isUpdating: boolean
  /** True while THIS item's removal is in flight. */
  isRemoving: boolean
  onUpdateQuantity: (quantity: number) => void
  onRemove: () => void
}

const STYLES = {
  page: { sizes: '112px', thumb: 'size-24 sm:size-28' },
  drawer: { sizes: '88px', thumb: 'size-[88px]' },
} as const

const stepButton = 'grid size-11 place-items-center rounded-full disabled:cursor-not-allowed disabled:text-muted-foreground'

/**
 * The single cart item card, shared by app/cart/page.tsx ('page') and the
 * cart drawer ('drawer'). Subscription lines show their badge and a fixed
 * quantity (subscription groups are priced server-side, so quantity edits
 * are remove + re-add).
 *
 * The in-flight state is `data-busy`. Nothing in here animates beyond the loading
 * spinner: the bag is a calm place.
 */
export function CartLineItemCard({
  item,
  currencyCode,
  variant,
  isUpdating,
  isRemoving,
  onUpdateQuantity,
  onRemove,
}: CartLineItemCardProps) {
  const s = STYLES[variant]
  const busy = isUpdating || isRemoving
  const Heading = variant === 'page' ? 'h2' : 'h3'
  // The full-page cart treats "minus at qty 1" as remove; the drawer clamps at 1.
  const removeAtOne = variant === 'page'
  // Medusa v2 puts the variant title on the line item itself; `variant.title`
  // is only there when the cart was fetched with field expansion (useCart
  // doesn't), which is why the size/colour line was always missing.
  const variantLabel = item.variant_title ?? item.variant?.title

  return (
    <div>
      <div data-busy={busy} className="flex gap-4 data-[busy=true]:opacity-60">
        <div className={`relative shrink-0 overflow-hidden rounded-2xl bg-muted ${s.thumb}`}>
          <Image
            src={getProductImage(item.thumbnail, item.product_id || item.id)}
            alt={item.title}
            fill
            sizes={s.sizes}
            className="object-cover"
          />
        </div>

        <div className="flex min-w-0 flex-1 flex-col justify-between gap-2">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <Heading className="text-sm font-black leading-5 sm:text-base">
                {item.title}
              </Heading>
              {variantLabel && variantLabel !== 'Default' && (
                <p className="mt-1 text-xs font-black uppercase tracking-[0.1em] text-accent">
                  {variantLabel}
                </p>
              )}
              <p className="mt-1 text-sm font-bold text-muted-foreground">
                {formatPrice(item.unit_price, currencyCode)} each
              </p>
              <SubscriptionLineBadge item={item} />
            </div>
            <button
              type="button"
              onClick={onRemove}
              disabled={busy}
              className="-mr-2 -mt-2 grid size-11 shrink-0 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:cursor-not-allowed disabled:opacity-40"
              aria-label={`Remove ${item.title} from cart`}
            >
              {isRemoving ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <Trash2 size={18} strokeWidth={2.2} />
              )}
            </button>
          </div>

          <div className="flex items-center justify-between gap-3">
            {/* Subscription lines are priced as a GROUP server-side; quantity
                edits go through the stock route which skips that re-pricing,
                so they're fixed here (remove + re-add to change). */}
            {isSubscriptionLine(item) ? (
              <span className="text-sm font-black">
                Qty {item.quantity}
              </span>
            ) : (
              <div className="flex items-center rounded-full border-2 border-border bg-background">
                <button
                  type="button"
                  onClick={() =>
                    item.quantity > 1
                      ? onUpdateQuantity(item.quantity - 1)
                      : removeAtOne
                        ? onRemove()
                        : undefined
                  }
                  disabled={busy || (!removeAtOne && item.quantity <= 1)}
                  aria-label="Decrease quantity"
                  className={stepButton}
                >
                  <Minus size={16} strokeWidth={2.8} />
                </button>
                <span className="grid w-7 place-items-center text-sm font-black">
                  {isUpdating ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : (
                    item.quantity
                  )}
                </span>
                <button
                  type="button"
                  onClick={() => onUpdateQuantity(item.quantity + 1)}
                  disabled={busy}
                  aria-label="Increase quantity"
                  className={stepButton}
                >
                  <Plus size={16} strokeWidth={2.8} />
                </button>
              </div>
            )}

            {/* `total` is the line total AFTER its adjustments. Multiplying
                unit_price × quantity ignores line-level promotions, so after a
                promo the rows visibly disagreed with the summary's discount. */}
            <p className="font-heading text-xl tracking-tight">
              {formatPrice(item.total ?? item.unit_price * item.quantity, currencyCode)}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

"use client";

import { useEffect, useRef, useCallback } from "react";
import { useCart } from "@/hooks/use-cart";
import Link from "next/link";
import { X, ShoppingBag } from "lucide-react";
import { CartLineItemCard } from "@/components/cart/cart-line-item-card";
import { isSubscriptionCart } from "@/lib/subscription-cart";
import { formatPrice } from "@/lib/utils/format-price";
import { PromoCodeInput } from "@/components/checkout/promo-code-input";
import { ClientPluginSlot } from "@/components/ClientPluginSlot";
import { Sticker } from "@/components/porch/decor";
import { pill, pillGhost } from "@/components/porch/ui";
import type { CartLineItem } from "@/types";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

// The bag opens from the right edge, where shoppers expect it, with a short fade
// and nothing else: no slide, no bounce, nothing decorating the money. It is mounted
// once by CartDrawerHost in app/layout.tsx, so it sits outside the page wrapper and
// uses only the store's base color tokens.
//
// Keep the open/close wiring, the line-item list, the subtotal and the checkout
// button's destination, and keep the plugin slot tags exactly where they are:
// plugin installs target them by name, and a moved or deleted tag breaks them silently.
export default function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const {
    cart,
    removeItem,
    updateItem,
    itemCount,
    subtotal,
    isLoading,
    appliedPromoCodes,
    discountTotal,
    applyPromoCode,
    removePromoCode,
    isApplyingPromo,
    isRemovingPromo,
    isUpdatingItem,
    updatingItemId,
    isRemovingItem,
    removingItemId,
  } = useCart();

  const drawerRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  // Focus the close button when drawer opens
  useEffect(() => {
    if (isOpen) {
      closeButtonRef.current?.focus();
    }
  }, [isOpen]);

  // Close on Escape key
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  // Trap focus inside drawer
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key !== "Tab" || !drawerRef.current) return;

    const focusable = drawerRef.current.querySelectorAll<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
    );
    if (focusable.length === 0) return;

    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }, []);

  // Invisible slot: fires AddToCart event trackers whenever cart state is
  // available. It is rendered BEFORE the isOpen branch on purpose, so cart
  // trackers do not only mount while the buyer has the drawer open.
  //
  // EXACTLY ONE `cartUpdate` tag may exist in this file. The install codemod
  // matches the slot with a non-global regex and splices the plugin's block
  // after the FIRST match, so a second copy decides where every future
  // cart-tracker install lands.
  const cartContext = { cartId: cart?.id, itemCount, total: cart?.total };

  const currencyCode =
    cart?.currency_code || cart?.region?.currency_code || "usd";
  const formattedSubtotal = formatPrice(subtotal || 0, currencyCode);

  return (
    <>
      {/* cartUpdate slot: invisible, fires on cart state */}
      <ClientPluginSlot name="cartUpdate" context={cartContext} />

      {!isOpen ? null : (
        <>
          {/* Backdrop */}
          <div
            onClick={onClose}
            className="porch-drawer-in fixed inset-0 z-50 bg-foreground/45"
          />

          {/* Drawer */}
          <div
            ref={drawerRef}
            role="dialog"
            aria-modal="true"
            aria-label="Shopping bag"
            onKeyDown={handleKeyDown}
            className="porch-drawer-in fixed inset-y-0 right-0 z-50 flex w-full max-w-md flex-col border-l-2 border-border bg-background text-foreground shadow-[-10px_0_0_hsl(var(--accent))]"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b-2 border-border px-5 py-4">
              <h2 className="flex items-center gap-3 font-heading text-3xl leading-none">
                <span aria-hidden className="grid size-10 place-items-center rounded-full bg-muted">
                  <ShoppingBag size={19} strokeWidth={2.4} />
                </span>
                Bag ({itemCount})
              </h2>
              <button
                ref={closeButtonRef}
                onClick={onClose}
                aria-label="Close bag"
                className="grid size-11 place-items-center rounded-full transition-colors hover:bg-muted focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-offset-2 focus-visible:outline-ring"
              >
                <X size={20} strokeWidth={2.6} />
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto px-5 py-5">
              {isLoading ? (
                <div className="space-y-6">
                  {[1, 2].map((i) => (
                    <div key={i} className="flex gap-4">
                      <div className="size-[88px] shrink-0 animate-pulse rounded-2xl bg-muted" />
                      <div className="flex-1 space-y-3 py-1">
                        <div className="h-4 w-3/4 animate-pulse rounded-full bg-muted" />
                        <div className="h-3 w-1/3 animate-pulse rounded-full bg-muted" />
                        <div className="h-3 w-1/2 animate-pulse rounded-full bg-muted" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : !cart?.items || cart.items.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center text-center">
                  <Sticker name="ghost-empty-bag" className="mb-5 h-32 w-auto" />
                  <p className="font-heading text-3xl">Your bag is empty</p>
                  <p className="mt-2 max-w-xs text-sm leading-6 text-muted-foreground">
                    Everything you add will be waiting for you here.
                  </p>
                  <button
                    onClick={onClose}
                    className={`${pill} mt-6`}
                  >
                    Continue Shopping
                  </button>
                </div>
              ) : (
                <div className="divide-y-2 divide-border/15">
                  {cart.items.map((item: CartLineItem) => (
                    <div key={item.id} className="py-5 first:pt-0">
                      <CartLineItemCard
                        item={item}
                        currencyCode={currencyCode}
                        variant="drawer"
                        isUpdating={isUpdatingItem && updatingItemId === item.id}
                        isRemoving={isRemovingItem && removingItemId === item.id}
                        onUpdateQuantity={(quantity) =>
                          updateItem({ lineId: item.id, quantity })
                        }
                        onRemove={() => removeItem(item.id)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {cart?.items && cart.items.length > 0 && (
              <div className="space-y-4 border-t-2 border-border bg-muted px-5 py-5">
                {/* Promo codes don't combine with subscriptions (the server
                rejects the attach), so the field is hidden on subscription carts,
                same as checkout's order summary. */}
                {!isSubscriptionCart(cart) && (
                  <PromoCodeInput
                    appliedPromoCodes={appliedPromoCodes}
                    discountTotal={discountTotal}
                    currencyCode={currencyCode}
                    isApplyingPromo={isApplyingPromo}
                    isRemovingPromo={isRemovingPromo}
                    onApply={applyPromoCode}
                    onRemove={removePromoCode}
                  />
                )}
                <div className="space-y-2 text-sm font-bold">
                  <div className="flex items-baseline justify-between">
                    <span className="font-black uppercase tracking-[0.1em]">
                      Subtotal
                    </span>
                    <span className="font-heading text-2xl tracking-tight">
                      {formattedSubtotal}
                    </span>
                  </div>
                  {discountTotal > 0 && (
                    <div className="flex items-baseline justify-between text-primary">
                      <span>Discount</span>
                      <span>-{formatPrice(discountTotal, currencyCode)}</span>
                    </div>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  Shipping and taxes calculated at checkout
                </p>
                {/* Upsell blocks, loyalty balance */}
                <ClientPluginSlot
                  name="cartDrawerFooter"
                  context={{ cartId: cart?.id, total: cart?.total, itemCount }}
                />
                <Link
                  href="/checkout"
                  onClick={onClose}
                  className={`${pill} w-full`}
                >
                  Checkout
                </Link>
                <Link
                  href="/cart"
                  onClick={onClose}
                  className={`${pillGhost} w-full bg-background`}
                >
                  View Full Cart
                </Link>
                <button
                  onClick={onClose}
                  className="min-h-11 w-full text-sm font-black underline underline-offset-4"
                >
                  Continue Shopping
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </>
  );
}

import { useId } from 'react'
import { ASSET_BASE, STICKERS, type StickerName } from './assets'
import { SEASON } from './season'

/*
 * Seasonal decorations. Every piece is decoration only: hidden from assistive tech, never
 * clickable, and gone entirely when SEASON is not 'halloween'. Keep them out of product
 * cards and away from the price, size, color and Add to Bag controls.
 */

/** A die-cut sticker from the Halloween art pack. `float` gives it a slow bob (a, b and c differ in pace). */
export function Sticker({
  name,
  className = '',
  float,
}: {
  name: StickerName
  className?: string
  float?: 'a' | 'b' | 'c'
}) {
  if (SEASON !== 'halloween') return null
  const { w, h } = STICKERS[name]
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={`${ASSET_BASE}/${name}.webp`}
      alt=""
      aria-hidden
      width={w}
      height={h}
      loading="lazy"
      decoding="async"
      data-float={float}
      className={`porch-sticker pointer-events-none select-none ${className}`}
    />
  )
}

const BULB_COLORS = ['hsl(var(--primary))', 'hsl(43 100% 90%)', 'hsl(var(--accent))', 'hsl(28 90% 72%)']
const BULB_COLORS_LIGHT = ['hsl(var(--primary))', 'hsl(var(--accent))', 'hsl(28 90% 62%)', 'hsl(var(--foreground))']

/** A strand of porch lights drawn in code. The bulbs twinkle unless motion is paused.
 * `onLight` draws the strand for a cream page; the default is for the dusk sky. */
export function StringLights({ className = '', onLight = false }: { className?: string; onLight?: boolean }) {
  if (SEASON !== 'halloween') return null
  const wireColor = onLight ? 'hsl(var(--foreground) / 0.45)' : 'hsl(var(--sky-ink) / 0.55)'
  const capColor = onLight ? 'hsl(var(--foreground) / 0.7)' : 'hsl(var(--sky-ink) / 0.7)'
  const colors = onLight ? BULB_COLORS_LIGHT : BULB_COLORS
  const width = 1440
  const swags = 6
  const span = width / swags
  let wire = 'M0 8'
  const bulbs: { x: number; y: number }[] = []
  for (let i = 0; i < swags; i++) {
    const x0 = i * span
    wire += ` Q${x0 + span / 2} 50 ${x0 + span} 8`
    for (const t of [0.2, 0.4, 0.6, 0.8]) {
      // point on the quadratic curve, so every bulb hangs from the wire
      const x = x0 + span * t
      const y = 8 + 2 * (1 - t) * t * 42
      bulbs.push({ x, y })
    }
  }
  return (
    <div aria-hidden className={`pointer-events-none flex justify-center overflow-hidden ${className}`}>
      <svg viewBox={`0 0 ${width} 64`} width={width} height={64} className="h-16 w-[1440px] max-w-none shrink-0 2xl:h-auto 2xl:w-full">
        <path d={wire} fill="none" stroke={wireColor} strokeWidth="2" />
        {bulbs.map((bulb, index) => (
          <g key={index} data-twinkle style={{ animationDelay: `${(index % 7) * -0.9}s` }}>
            <rect x={bulb.x - 3} y={bulb.y - 1} width="6" height="6" rx="1.5" fill={capColor} />
            <ellipse cx={bulb.x} cy={bulb.y + 12} rx="6.5" ry="9" fill={colors[index % colors.length]} />
          </g>
        ))}
      </svg>
    </div>
  )
}

/** Scalloped edge between two sections. It takes its color from the text color you give it. */
export function ScallopDivider({ className = '', flip = false }: { className?: string; flip?: boolean }) {
  const id = useId()
  return (
    <svg
      data-quirk="divider"
      aria-hidden
      className={`pointer-events-none block h-[18px] w-full ${flip ? 'rotate-180' : ''} ${className}`}
    >
      <defs>
        <pattern id={id} width="36" height="18" patternUnits="userSpaceOnUse">
          <circle cx="18" cy="0" r="18" fill="currentColor" />
        </pattern>
      </defs>
      <rect width="100%" height="18" fill={`url(#${id})`} />
    </svg>
  )
}

/** Picket fence silhouette, used as the ground line of the dusk hero and the footer porch. */
export function FenceDivider({ className = '' }: { className?: string }) {
  const id = useId()
  if (SEASON !== 'halloween') return null
  return (
    <svg data-quirk="divider" aria-hidden className={`pointer-events-none block h-[46px] w-full ${className}`}>
      <defs>
        <pattern id={id} width="30" height="46" patternUnits="userSpaceOnUse">
          <path d="M5 46V12l8-10 8 10v34z" fill="currentColor" />
          <rect x="0" y="22" width="30" height="5" fill="currentColor" />
          <rect x="0" y="36" width="30" height="5" fill="currentColor" />
        </pattern>
      </defs>
      <rect width="100%" height="46" fill={`url(#${id})`} />
    </svg>
  )
}

/** The footer scene: a little porch at dusk, built from the sticker pack. */
export function PorchScene() {
  if (SEASON !== 'halloween') return null
  return (
    <div aria-hidden className="pointer-events-none relative mx-auto h-[150px] w-full max-w-[1440px] [mask-image:linear-gradient(to_right,transparent,#000_5%,#000_95%,transparent)] sm:h-[190px]">
      <StringLights className="absolute inset-x-0 top-0" />
      <Sticker name="pumpkin-stack" className="absolute bottom-[30px] left-[4%] h-[92px] w-auto sm:h-[128px]" />
      <Sticker name="lantern" float="c" className="absolute bottom-[30px] left-[24%] hidden h-[96px] w-auto sm:block" />
      <Sticker
        name="ghost-peek"
        float="a"
        className="absolute bottom-[38px] left-1/2 h-[84px] w-auto -translate-x-1/2 [clip-path:inset(0_0_10%_0)] sm:h-[112px]"
      />
      <Sticker name="black-cat" className="absolute bottom-[30px] right-[22%] hidden h-[98px] w-auto sm:block" />
      <Sticker name="pumpkin-happy" className="absolute bottom-[30px] right-[4%] h-[80px] w-auto sm:h-[108px]" />
      <FenceDivider className="absolute inset-x-0 bottom-0 text-[hsl(var(--sky-deep))]" />
    </div>
  )
}

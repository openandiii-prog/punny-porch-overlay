import type { ReactNode } from 'react'
import SiteHeader from './site-header'
import SiteFooter from './site-footer'
import { MotionBoot } from './motion'
import { SEASON } from './season'

/**
 * Page frame for every designed route except the home page (which builds its own hero around
 * the same header and footer). The `porch` class scopes all of the store's CSS, so the
 * chassis surfaces (checkout, account, auth, policies) are never affected by it.
 */
export default function PorchPage({
  children,
  className = '',
  calm = false,
}: {
  children: ReactNode
  className?: string
  /** For the bag: every decoration on the page holds still. */
  calm?: boolean
}) {
  return (
    <div
      className="porch flex min-h-screen flex-col overflow-x-clip bg-background text-foreground"
      data-season={SEASON}
      data-calm={calm || undefined}
    >
      <MotionBoot />
      <SiteHeader />
      <div className={`flex-1 ${className}`}>{children}</div>
      <SiteFooter />
    </div>
  )
}

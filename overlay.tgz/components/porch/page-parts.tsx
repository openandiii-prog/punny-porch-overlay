import type { ReactNode } from 'react'
import { StringLights } from './decor'
import { eyebrow as eyebrowClass, pageTitle, wrap } from './ui'

/** The peach title band that opens the shop, collection and info pages. */
export function PageBand({
  eyebrow,
  title,
  children,
  aside,
}: {
  eyebrow?: string
  title: ReactNode
  children?: ReactNode
  aside?: ReactNode
}) {
  return (
    <section className="relative overflow-hidden border-b-2 border-border bg-muted">
      <StringLights onLight className="absolute inset-x-0 top-0" />
      <div className={`${wrap} relative flex flex-col gap-7 pb-10 pt-20 sm:flex-row sm:items-end sm:justify-between sm:pb-12`}>
        <div className="max-w-3xl">
          {eyebrow && <p className={eyebrowClass}>{eyebrow}</p>}
          <h1 className={`${pageTitle} mt-3`}>{title}</h1>
          {children}
        </div>
        {aside}
      </div>
    </section>
  )
}

/** Loading placeholder with the same shape as the product grid. */
export function GridSkeleton({ count = 8 }: { count?: number }) {
  return (
    <div aria-hidden className="grid grid-cols-2 gap-x-4 gap-y-9 md:grid-cols-3 lg:grid-cols-4 lg:gap-x-6">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i}>
          <div className="aspect-[4/5] animate-pulse rounded-[30px] bg-muted" />
          <div className="mt-4 h-4 w-3/4 animate-pulse rounded-full bg-muted" />
        </div>
      ))}
    </div>
  )
}

/** Loading placeholder for a title band. */
export function BandSkeleton() {
  return (
    <section aria-hidden className="border-b-2 border-border bg-muted">
      <div className={`${wrap} pb-12 pt-20`}>
        <div className="h-3 w-40 animate-pulse rounded-full bg-background" />
        <div className="mt-5 h-14 w-2/3 max-w-md animate-pulse rounded-2xl bg-background" />
      </div>
    </section>
  )
}

'use client'

import Link from 'next/link'
import { useBrand } from '@/hooks/use-brand'
import { usePolicies } from '@/hooks/use-policies'
import { clearConsent } from '@/lib/cookie-consent'
import { PorchScene, ScallopDivider } from './decor'
import { PauseToggle } from './motion'

const policyLinks = [
  ['Privacy', '/privacy', 'privacy_policy'],
  ['Terms', '/terms', 'terms_of_service'],
  ['Refunds', '/refund-policy', 'refund_policy'],
  ['Cookies', '/cookie-policy', 'cookie_policy'],
] as const

const heading = 'text-xs font-black uppercase tracking-[0.14em] text-[hsl(var(--sky-accent))]'

/**
 * The one footer every designed page shares. It links every policy the store has configured
 * and carries the manage-cookies control (data-manage-cookies), which the platform requires.
 */
export default function SiteFooter() {
  const { brand } = useBrand()
  const { policies } = usePolicies()
  const storeName = brand?.storeName || 'The Punny Porch'

  return (
    <footer data-build="porch-2026-10-05" className="relative bg-[hsl(var(--sky))] text-[hsl(var(--sky-ink))]">
      <ScallopDivider className="text-background" />
      <PorchScene />
      <div className="porch-grain relative bg-[hsl(var(--sky-deep))] px-5 py-11 sm:px-8 lg:px-12">
        <div className="relative mx-auto grid max-w-[1440px] gap-9 md:grid-cols-[1.2fr_1fr_1fr]">
          <div>
            <Link href="/" className="font-heading text-3xl tracking-tight">The Punny Porch</Link>
            <p className="mt-3 max-w-xs text-sm leading-6 text-[hsl(var(--sky-soft))]">
              Cozy punny Halloween tees for the moms who bring the good candy.
            </p>
          </div>
          <div>
            <p className={heading}>Browse</p>
            <div className="mt-3 flex flex-col items-start gap-2 text-sm font-bold">
              <Link href="/products">Shop tees</Link>
              <Link href="/collections">Collections</Link>
              <Link href="/about">Our porch</Link>
              <Link href="/faq">FAQ</Link>
              <Link href="/contact">Contact</Link>
            </div>
          </div>
          <div>
            <p className={heading}>Good to know</p>
            <div className="mt-3 flex flex-col items-start gap-2 text-sm font-bold">
              {policyLinks
                .filter(([, , key]) => policies?.[key])
                .map(([label, href]) => (
                  <Link key={href} href={href}>{label}</Link>
                ))}
              <button
                type="button"
                data-manage-cookies
                onClick={() => {
                  clearConsent()
                  window.dispatchEvent(new Event('manage-cookies'))
                }}
                className="text-left"
              >
                Manage cookies
              </button>
              <PauseToggle className="text-left" />
            </div>
          </div>
        </div>
        <p className="relative mx-auto mt-10 max-w-[1440px] border-t border-[hsl(var(--sky-ink)/0.15)] pt-5 text-xs font-bold text-[hsl(var(--sky-accent))]">
          © {new Date().getFullYear()} {storeName}. Porch-party style, all season long.
        </p>
      </div>
    </footer>
  )
}

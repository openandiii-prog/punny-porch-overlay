'use client'

import { useEffect, useRef } from 'react'
import { FX_SRC, POSTER_SRC } from './fx-manifest'
import { useMotionAllowed } from './motion'
import { SEASON } from './season'

type PorchFx = {
  mount: (canvas: HTMLCanvasElement, options: { signal: AbortSignal; host: HTMLElement }) => Promise<boolean>
}
type FxWindow = Window & { __porchFx?: PorchFx; __porchFxLoading?: Promise<PorchFx> }

/** Loads the prebuilt WebGPU bundle once per page load, as a plain same-origin module script. */
function loadFx(): Promise<PorchFx> {
  const w = window as FxWindow
  if (w.__porchFx) return Promise.resolve(w.__porchFx)
  if (!w.__porchFxLoading) {
    w.__porchFxLoading = new Promise<PorchFx>((resolve, reject) => {
      const script = document.createElement('script')
      script.type = 'module'
      script.src = FX_SRC
      script.onload = () => (w.__porchFx ? resolve(w.__porchFx) : reject(new Error('porch-fx did not register')))
      script.onerror = () => reject(new Error('porch-fx failed to load'))
      document.head.appendChild(script)
    })
  }
  return w.__porchFxLoading
}

/**
 * The home hero's sky. Three layers, bottom to top:
 *   1. a still of the dusk sky (rendered from the same shader), which is what every visitor gets first
 *   2. a slow CSS fog drift, so phones and browsers without WebGPU still see gentle motion
 *   3. the live WebGPU sky with a lantern glow under the pointer, on computers that support it
 * Reduced motion, the footer's "Pause animations" control, any GPU error, or `?fx=off` in the
 * address all leave the still in place. Renders nothing outside the Halloween season.
 */
export default function DuskHero() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const motion = useMotionAllowed()

  useEffect(() => {
    const canvas = canvasRef.current
    const host = canvas?.closest<HTMLElement>('[data-dusk-host]')
    if (!canvas || !host || !motion) return
    if (!('gpu' in navigator)) return
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return
    if (new URLSearchParams(window.location.search).get('fx') === 'off') return

    const controller = new AbortController()
    const start = () => {
      if (controller.signal.aborted) return
      loadFx()
        .then((fx) => fx.mount(canvas, { signal: controller.signal, host }))
        .catch(() => {
          // the still stays up: nothing else to do
        })
    }
    const idle = window.setTimeout(start, 350)
    return () => {
      window.clearTimeout(idle)
      controller.abort()
    }
  }, [motion])

  if (SEASON !== 'halloween') return null

  return (
    <div aria-hidden className="porch-grain pointer-events-none absolute inset-0 overflow-hidden bg-[hsl(var(--sky))]">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={POSTER_SRC} alt="" fetchPriority="high" decoding="async" className="absolute inset-0 h-full w-full object-cover" />
      <div className="porch-fog" />
      <div className="porch-fog" data-layer="b" />
      <canvas ref={canvasRef} data-dusk-canvas className="absolute inset-0 h-full w-full opacity-0 transition-opacity duration-700 data-[live]:opacity-100" />
    </div>
  )
}

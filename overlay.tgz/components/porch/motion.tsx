'use client'

import { useEffect, useSyncExternalStore, type RefObject } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'

gsap.registerPlugin(ScrollTrigger)

const KEY = 'porch-motion'
const EVENT = 'porch-motion-change'
const REDUCED = '(prefers-reduced-motion: reduce)'

function readPaused() {
  try {
    return localStorage.getItem(KEY) === 'paused'
  } catch {
    return false
  }
}

function subscribe(onChange: () => void) {
  const media = window.matchMedia(REDUCED)
  media.addEventListener('change', onChange)
  window.addEventListener(EVENT, onChange)
  return () => {
    media.removeEventListener('change', onChange)
    window.removeEventListener(EVENT, onChange)
  }
}

/** True once the shopper has pressed "Pause animations" (remembered across visits). */
export function useMotionPaused() {
  return useSyncExternalStore(subscribe, readPaused, () => false)
}

/** True when movement is welcome: no reduced-motion setting and not paused by the shopper. */
export function useMotionAllowed() {
  return useSyncExternalStore(
    subscribe,
    () => !readPaused() && !window.matchMedia(REDUCED).matches,
    () => false,
  )
}

export function setMotionPaused(paused: boolean) {
  try {
    if (paused) localStorage.setItem(KEY, 'paused')
    else localStorage.removeItem(KEY)
  } catch {
    // private mode: the choice still applies for this page view
  }
  document.documentElement.toggleAttribute('data-porch-paused', paused)
  window.dispatchEvent(new Event(EVENT))
}

/** Mirrors the saved pause choice onto <html> so the CSS decorations follow it. Renders nothing. */
export function MotionBoot() {
  useEffect(() => {
    document.documentElement.toggleAttribute('data-porch-paused', readPaused())
  }, [])
  return null
}

/**
 * The store's one entrance animation: anything marked data-rise inside `scope` fades up once
 * as it scrolls into view. Same values the home page has always used.
 */
export function usePorchReveals(scope: RefObject<HTMLElement | null>) {
  const allowed = useMotionAllowed()
  useGSAP(
    () => {
      if (!allowed) return
      gsap.utils.toArray<HTMLElement>('[data-rise]').forEach((element) => {
        gsap.from(element, {
          autoAlpha: 0,
          y: 34,
          duration: 0.65,
          ease: 'power3.out',
          scrollTrigger: { trigger: element, start: 'top 88%' },
        })
      })
    },
    { scope, dependencies: [allowed], revertOnUpdate: true },
  )
}

/** Footer control: lets anyone stop every animation on the site. */
export function PauseToggle({ className = '' }: { className?: string }) {
  const paused = useMotionPaused()
  return (
    <button type="button" aria-pressed={paused} onClick={() => setMotionPaused(!paused)} className={className}>
      {paused ? 'Play animations' : 'Pause animations'}
    </button>
  )
}

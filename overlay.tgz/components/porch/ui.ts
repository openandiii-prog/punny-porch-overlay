// Shared class strings for the designed pages, so every page speaks the same visual language.

export const wrap = 'mx-auto w-full max-w-[1440px] px-5 sm:px-8 lg:px-12'

export const eyebrow = 'text-xs font-black uppercase tracking-[0.16em] text-accent'

export const pageTitle = 'font-heading text-5xl leading-[0.9] tracking-[-0.045em] sm:text-6xl lg:text-7xl'

export const sectionTitle = 'font-heading text-4xl leading-none tracking-[-0.04em] sm:text-5xl'

/** Primary action. Same pill the home page and product page already use. */
export const pill =
  'inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-black uppercase tracking-[0.11em] text-primary-foreground shadow-[4px_5px_0_hsl(var(--foreground))] transition-transform hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground disabled:shadow-none'

/** Secondary action. */
export const pillGhost =
  'inline-flex min-h-11 items-center justify-center gap-2 rounded-full border-2 border-border px-6 py-3 text-sm font-black uppercase tracking-[0.11em] transition-colors hover:bg-foreground hover:text-background disabled:cursor-not-allowed disabled:opacity-50'

/** Small round icon button, 44px hit area. */
export const iconButton =
  'grid size-11 place-items-center rounded-full transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:text-muted-foreground'

export const card = 'rounded-[30px] border-2 border-border bg-background'

export const field =
  'w-full rounded-2xl border-2 border-border bg-background px-4 py-3 text-base font-bold placeholder:font-normal placeholder:text-muted-foreground'

export const label = 'mb-2 block text-xs font-black uppercase tracking-[0.14em]'

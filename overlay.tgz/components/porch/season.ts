/**
 * One switch for seasonal dressing.
 * 'halloween' turns on the dusk hero and footer plus every decoration.
 * 'none' is the plain cream store: same layout, no decorations.
 */
export const SEASON: 'halloween' | 'none' = 'halloween'

'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import { Menu, Search, ShoppingBag, User, X } from 'lucide-react'
import { useCart } from '@/hooks/use-cart'
import { useAuth } from '@/hooks/use-auth'

const NAV = [
  { href: '/products', label: 'Shop tees', mobile: 'Shop all tees' },
  { href: '/collections', label: 'The collection', mobile: 'The collection' },
  { href: '/about', label: 'Our porch', mobile: 'Our porch' },
] as const

/**
 * The one header every designed page shares. Search, account and bag are always reachable.
 * It never mounts a cart drawer of its own: CartDrawerHost in app/layout.tsx owns that.
 */
export default function SiteHeader() {
  const pathname = usePathname()
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { itemCount } = useCart()
  const { isLoggedIn } = useAuth()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 70)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const isCurrent = (href: string) => pathname === href || pathname?.startsWith(`${href}/`)

  return (
    <header
      data-nav-behavior="solid-on-scroll"
      data-scrolled={scrolled}
      className="sticky top-0 z-40 border-b border-border/10 bg-background/92 backdrop-blur transition-shadow duration-200 data-[scrolled=true]:bg-background data-[scrolled=true]:shadow-[0_9px_28px_hsl(var(--foreground)/0.12)]"
    >
      <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
        <Link href="/" className="font-heading text-[1.55rem] tracking-tight">The Punny Porch</Link>
        <nav className="hidden items-center gap-7 text-sm font-extrabold uppercase tracking-[0.11em] lg:flex" aria-label="Primary navigation">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={isCurrent(item.href) ? 'page' : undefined}
              className="transition-colors hover:text-primary aria-[current=page]:text-primary"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-1 sm:gap-2">
          <Link href="/search" aria-label="Search" className="grid size-11 place-items-center rounded-full transition-colors hover:bg-muted">
            <Search size={19} strokeWidth={2.4} />
          </Link>
          <Link
            href={isLoggedIn ? '/account' : '/auth/login'}
            aria-label={isLoggedIn ? 'Account' : 'Sign in'}
            className="hidden size-11 place-items-center rounded-full transition-colors hover:bg-muted sm:grid"
          >
            <User size={19} strokeWidth={2.4} />
          </Link>
          <Link href="/cart" aria-label="Shopping bag" className="relative grid size-11 place-items-center rounded-full transition-colors hover:bg-muted">
            <ShoppingBag size={20} strokeWidth={2.4} />
            {itemCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 grid size-5 place-items-center rounded-full bg-primary text-[10px] font-black text-primary-foreground">
                {itemCount}
              </span>
            )}
          </Link>
          <button
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            className="grid size-11 place-items-center rounded-full bg-foreground text-background lg:hidden"
            aria-label="Toggle navigation"
            aria-expanded={menuOpen}
          >
            {menuOpen ? <X size={20} /> : <Menu size={21} />}
          </button>
        </div>
      </div>
      {menuOpen && (
        <nav className="border-t border-border/10 bg-background px-5 py-5 lg:hidden" aria-label="Mobile navigation">
          <div className="flex flex-col gap-4 font-heading text-lg">
            {NAV.map((item) => (
              <Link key={item.href} onClick={() => setMenuOpen(false)} href={item.href}>{item.mobile}</Link>
            ))}
            <Link onClick={() => setMenuOpen(false)} href={isLoggedIn ? '/account' : '/auth/login'}>
              {isLoggedIn ? 'My account' : 'Sign in'}
            </Link>
          </div>
        </nav>
      )}
    </header>
  )
}

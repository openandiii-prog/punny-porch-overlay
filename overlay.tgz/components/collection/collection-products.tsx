'use client'

import { Suspense, useRef, useState } from 'react'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import ProductGrid from '@/components/product/product-grid'
import Pagination from '@/components/product/pagination'

const PAGE_SIZE = 16

interface CollectionProductsProps {
  collectionId: string
}

function CollectionProductsContent({ collectionId }: CollectionProductsProps) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10) || 1)

  const [result, setResult] = useState<{ count: number; loading: boolean }>({ count: 0, loading: true })
  const gridRef = useRef<HTMLDivElement>(null)

  const totalPages = Math.max(1, Math.ceil(result.count / PAGE_SIZE))

  const handlePageChange = (nextPage: number) => {
    const params = new URLSearchParams(searchParams.toString())
    if (nextPage > 1) params.set('page', String(nextPage))
    else params.delete('page')
    router.replace(`${pathname}?${params.toString()}`, { scroll: false })
    gridRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <div ref={gridRef} className="scroll-mt-28">
      <ProductGrid
        collectionId={collectionId}
        page={page}
        pageSize={PAGE_SIZE}
        onResult={setResult}
      />
      <Pagination page={page} totalPages={totalPages} onPageChange={handlePageChange} />
    </div>
  )
}

export default function CollectionProducts({ collectionId }: CollectionProductsProps) {
  return (
    <Suspense fallback={null}>
      <CollectionProductsContent collectionId={collectionId} />
    </Suspense>
  )
}

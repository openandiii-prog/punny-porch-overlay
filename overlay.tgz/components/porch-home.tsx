'use client'

import Link from 'next/link'
import { useRef } from 'react'
import { gsap } from 'gsap'
import { useGSAP } from '@gsap/react'
import { useProducts } from '@/hooks/use-products'
import { formatPrice } from '@/lib/utils/format-price'
import SiteHeader from '@/components/porch/site-header'
import SiteFooter from '@/components/porch/site-footer'
import DuskHero from '@/components/porch/dusk-hero'
import { FenceDivider, Sticker, StringLights } from '@/components/porch/decor'
import { MotionBoot, useMotionAllowed, usePorchReveals } from '@/components/porch/motion'
import { SEASON } from '@/components/porch/season'

const heroPhoto = 'https://ahjviugsxpwzpkyzgrhi.supabase.co/storage/v1/object/public/product-user-files/3a2e46ee-fc9b-4553-bfd0-804cdf3365a9%2F01M46FEBEJN8VC31EBRR3VT39B.jpeg'
const storyPhoto = 'https://ahjviugsxpwzpkyzgrhi.supabase.co/storage/v1/object/public/product-user-files/3a2e46ee-fc9b-4553-bfd0-804cdf3365a9%2F01M46FEBEMSC77322ABBFDY37N.jpeg'

const halloween = SEASON === 'halloween'

function productImage(product: any) {
  if (typeof product.thumbnail === 'string') return product.thumbnail
  const first = product.images?.[0]
  return typeof first === 'string' ? first : first?.url
}

export default function PorchHome() {
  const shell = useRef<HTMLDivElement>(null)
  const { data, isLoading } = useProducts({ limit: 4 })
  const featured = data?.products || []
  const motion = useMotionAllowed()

  // The hero's own entrance. Everything below the hero uses the shared data-rise reveal.
  useGSAP(() => {
    if (!motion) return
    gsap.from('[data-hero-copy]', { autoAlpha: 0, y: 28, duration: 0.75, stagger: 0.1, ease: 'power3.out' })
    gsap.from('[data-hero-photo]', { autoAlpha: 0, x: 34, duration: 0.9, delay: 0.12, ease: 'power3.out' })
  }, { scope: shell, dependencies: [motion], revertOnUpdate: true })
  usePorchReveals(shell)

  return (
    <div ref={shell} className="porch overflow-x-clip bg-background text-foreground" data-season={SEASON}>
      <MotionBoot />
      <SiteHeader />

      <main>
        {/* The hero is a "sky" surface: plain cream off season, a live dusk sky in the Halloween season.
            Every decoration in it is behind the copy and the photo, and none of it is clickable. */}
        <section data-dusk-host className="relative isolate overflow-hidden bg-[hsl(var(--sky))] text-[hsl(var(--sky-ink))]">
          <DuskHero />
          <StringLights className="absolute inset-x-0 top-0" />
          <Sticker name="moon-stars" float="c" className="absolute right-[3%] top-[70px] hidden h-24 w-auto xl:block" />
          <Sticker name="bat-a" float="a" className="absolute left-[44%] top-[84px] hidden h-12 w-auto md:block" />
          <Sticker name="bat-b" float="b" className="absolute left-[36%] top-[150px] hidden h-9 w-auto lg:block" />

          <div className="relative z-10 mx-auto grid max-w-[1440px] gap-8 px-5 pb-16 pt-16 sm:px-8 md:grid-cols-[0.93fr_1.07fr] md:items-center md:gap-12 md:pb-24 md:pt-16 lg:px-12">
            <div className="relative z-10 max-w-[650px] py-5 md:py-12">
              <p data-hero-copy className="mb-5 inline-flex rounded-full border border-[hsl(var(--sky-accent)/0.45)] bg-[hsl(var(--sky-accent)/0.14)] px-4 py-2 text-xs font-black uppercase tracking-[0.15em] text-[hsl(var(--sky-accent))]">Cute tees for spooky-season moms</p>
              <h1 data-hero-copy className="font-heading text-[clamp(3.9rem,8.2vw,8.9rem)] leading-[0.82] tracking-[-0.06em]">Puns,<br /><span className="text-primary">pumpkins</span><br />&amp; porch hangs.</h1>
              <p data-hero-copy className="mt-7 max-w-md text-base leading-7 text-[hsl(var(--sky-soft))] sm:text-lg">Feel-good Halloween tees made for coffee runs, class parties, and every little trick-or-treat tradition in between.</p>
              <div data-hero-copy className="mt-8 flex flex-wrap gap-3"><Link href="/products" className="porch-glaze rounded-full bg-primary px-6 py-3.5 text-sm font-black uppercase tracking-[0.11em] text-primary-foreground shadow-[4px_5px_0_hsl(var(--foreground))] transition-transform hover:-translate-y-0.5">Shop the tees</Link><Link href="/about" className="rounded-full border-2 border-[hsl(var(--sky-ink))] px-6 py-3 text-sm font-black uppercase tracking-[0.11em] transition-colors hover:bg-[hsl(var(--sky-ink))] hover:text-[hsl(var(--sky))]">Meet the porch</Link></div>
              <div data-hero-copy className="mt-10 flex items-center gap-5 text-xs font-extrabold uppercase tracking-[0.12em] text-[hsl(var(--sky-soft))]"><span>24 punny designs</span><span className="h-1 w-1 rounded-full bg-primary" /><span>Made for fall fun</span></div>
            </div>
            <div data-hero-photo className="relative min-h-[420px] overflow-hidden rounded-[42%_42%_18%_18%/28%_28%_18%_18%] border-[10px] border-muted bg-muted shadow-[12px_12px_0_hsl(var(--accent))] md:min-h-[560px]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={heroPhoto} alt="Mom and toddler in a pumpkin patch wearing the Gourd Vibes Only tee" className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute bottom-5 left-5 rounded-full bg-background px-4 py-2 text-xs font-black uppercase tracking-[0.12em] text-foreground">Mom-approved mischief</div>
            </div>
            {halloween
              ? <Sticker name="pumpkin-happy" float="a" className="absolute bottom-10 left-[44%] hidden h-24 w-auto md:block" />
              : <span aria-hidden className="absolute bottom-8 left-[46%] hidden text-7xl text-accent md:block">✦</span>}
          </div>
          <FenceDivider className="relative z-[5] -mb-px text-[hsl(var(--sky-deep))]" />
        </section>

        <section className="border-y-2 border-border bg-primary py-3 text-primary-foreground"><div className="mx-auto flex max-w-[1440px] flex-wrap justify-center gap-x-12 gap-y-2 px-5 text-center text-xs font-black uppercase tracking-[0.15em]"><span>Cozy cotton comfort</span><span>Easy everyday fits</span><span>Big pumpkin-energy</span></div></section>

        <section data-rise className="mx-auto max-w-[1440px] px-5 py-20 sm:px-8 lg:px-12">
          <div className="mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div className="relative"><p className="text-xs font-black uppercase tracking-[0.16em] text-accent">Fresh from the porch</p><h2 className="mt-2 font-heading text-5xl leading-none tracking-[-0.045em] sm:text-6xl">Pick your pun.</h2><Sticker name="candy-corn" float="b" className="absolute -right-28 -top-3 hidden h-20 w-auto sm:block" /></div><Link href="/products" className="w-fit border-b-2 border-primary pb-1 text-sm font-black uppercase tracking-[0.12em] text-primary">Shop all 24</Link></div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-9 lg:grid-cols-4 lg:gap-x-6">
            {isLoading && Array.from({ length: 4 }).map((_, index) => <div key={index} className="aspect-[4/5] animate-pulse rounded-[30px] bg-muted" />)}
            {featured.map((product: any) => {
              const image = productImage(product)
              const variant = product.variants?.[0]
              return <Link key={product.id} href={`/products/${product.handle}`} className="group block"><div className="relative aspect-[4/5] overflow-hidden rounded-[30px] bg-muted"><span className="absolute left-3 top-3 z-10 rounded-full bg-background px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-accent">Porch pick</span>{image ? <><img src={image} alt={product.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" /></> : <div className="grid h-full place-items-center p-5 text-center font-heading text-3xl text-accent">{product.title}</div>}</div><div className="mt-4 flex gap-2"><h3 className="flex-1 text-sm font-black leading-5 sm:text-base">{product.title}</h3><span className="text-sm font-black text-primary">{formatPrice(variant?.calculated_price?.calculated_amount || 2699, variant?.calculated_price?.currency_code || 'usd')}</span></div></Link>
            })}
          </div>
        </section>

        <section data-rise className="relative mx-auto grid max-w-[1440px] overflow-hidden bg-foreground md:grid-cols-2"><div className="relative order-2 min-h-[410px] md:order-1">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={storyPhoto} alt="Punny Porch tees styled on a cozy autumn porch" className="absolute inset-0 h-full w-full object-cover" /></div><div className="relative order-1 flex flex-col justify-center px-7 py-16 text-background sm:px-12 md:order-2 lg:px-20"><Sticker name="web-corner" className="absolute right-0 top-0 h-28 w-auto -scale-x-100 opacity-90" /><p className="text-xs font-black uppercase tracking-[0.16em] text-muted">The porch promise</p><h2 className="mt-4 max-w-md font-heading text-5xl leading-[0.9] tracking-[-0.04em] sm:text-6xl">Halloween joy,<br /><span className="text-primary">zero creepy.</span></h2><p className="mt-6 max-w-md leading-7 text-muted">We make the kind of tees that earn a grin in the school pick-up line and make your annual porch photo even better.</p><Link href="/about" className="mt-8 w-fit rounded-full bg-accent px-5 py-3 text-xs font-black uppercase tracking-[0.13em] text-accent-foreground transition-colors hover:bg-background hover:text-foreground">Why we make them</Link></div></section>

        <section data-rise className="mx-auto max-w-[1440px] px-5 py-20 sm:px-8 lg:px-12"><div className="relative overflow-hidden rounded-[36px] border-2 border-border bg-accent/15 px-6 py-12 text-center sm:px-12">{halloween ? <><Sticker name="ghost-wave" float="a" className="absolute left-5 top-5 hidden h-24 w-auto -rotate-6 md:block" /><Sticker name="leaves" float="c" className="absolute bottom-4 right-5 hidden h-20 w-auto md:block" /></> : <><span aria-hidden className="absolute -left-2 -top-8 font-heading text-8xl text-primary">✳</span><span aria-hidden className="absolute -bottom-8 -right-2 font-heading text-8xl text-accent">✳</span></>}<p className="text-xs font-black uppercase tracking-[0.16em] text-accent">Porch mail</p><h2 className="mx-auto mt-3 max-w-2xl font-heading text-5xl leading-[0.9] tracking-[-0.04em] sm:text-6xl">The best puns disappear first.</h2><p className="mx-auto mt-4 max-w-md leading-7 text-muted-foreground">Join for first dibs on cozy seasonal drops, porch-party styling ideas, and plenty of groan-worthy goodness.</p><Link href="/contact" className="mt-7 inline-flex rounded-full bg-foreground px-6 py-3.5 text-xs font-black uppercase tracking-[0.13em] text-background transition-transform hover:-translate-y-0.5">Join the list</Link></div></section>
      </main>

      <SiteFooter />
    </div>
  )
}
